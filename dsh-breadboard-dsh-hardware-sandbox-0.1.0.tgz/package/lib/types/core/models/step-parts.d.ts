/**
 * step.parts 客户端 —— 唯一一个「公共 API + 免鉴权 + 直接给 GLB」的模型来源
 * @module dsh-hardware-sandbox/core/models/step-parts
 *
 * ★★ 为什么是它（2026-10-07 核实，详见 `docs/05-模型来源与导入方案.md`）：
 *
 *   我们此前的核心障碍是「现成模型多为 STEP，而 three.js **没有** STEP loader」。
 *   **step.parts 为每件都生成了 GLB**，所以**不需要任何 CAD 转换管线**。
 *
 *   而且它是**唯一**能程序化直连的来源：
 *   | 来源 | 公共 API | 免登录 | 格式 |
 *   |---|---|---|---|
 *   | **step.parts** | ✅ | ✅ | **GLB 直链** |
 *   | Printables / Thingiverse | ❌ | ✅ | STL（可手动下） |
 *   | KiCad 3D | ❌ | ✅ | STEP+WRL，**仅芯片封装** |
 *   | GrabCAD / Ultra Librarian | ❌ | ❌ 要登录/注册 | STEP |
 *
 * ★ **SSRF 面为零的设计**：本模块只接受 **partId**，`glbUrl` 由**宿主自己**从 API 取，
 *   **URL 从不由客户端提供**。所以不存在"用户让宿主去抓任意地址"这条路。
 *
 * ★ **下载前先看 `byteSize`**：元数据里就有大小，**不满足上限的直接拒绝，不去下**。
 *   否则一个 52MB 的 Raspberry Pi 4B 会先把流量和时间花掉再被拒。
 */
import type { ModelCandidate } from '../../contracts/protocol.ts';
export declare class StepPartsError extends Error {
    readonly code: 'network' | 'not_found' | 'too_large' | 'bad_response';
    constructor(code: StepPartsError['code'], message: string);
}
export interface StepPartsClientOptions {
    readonly baseUrl?: string;
    /**
     * **GLB** 的下载上限（字节）。下载完成后按实际字节数强制判定。
     */
    readonly maxBytes?: number;
    /**
     * 元数据 `byteSize` 的预检上限（字节）。
     *
     * ★★ **`byteSize` 是 STEP 文件的大小，不是 GLB 的** —— 实测：
     *   | 件 | `byteSize`(STEP) | 实际 GLB |
     *   |---|---|---|
     *   | Raspberry Pi Pico | 1.7 MB | **570 KB** |
     *   | Raspberry Pi 4 Model B | 50.1 MB | **5.7 MB** |
     *
     *   GLB 通常比 STEP 小一个数量级（step.parts 的 GLB 是**预览用**的简化几何）。
     *   所以**不能拿 `byteSize` 直接卡 `maxBytes`** —— 那会拒掉一大批其实装得下的件。
     *   预检只用来挡住**明显离谱**的（如 STEP 就几百 MB），真正的闸门是下载后的实际字节数。
     */
    readonly precheckBytes?: number;
    readonly timeoutMs?: number;
    /** 注入 fetch 以便测试。 */
    readonly fetchImpl?: typeof fetch;
}
export declare class StepPartsClient {
    #private;
    constructor(options?: StepPartsClientOptions);
    /** 搜索。返回可直接渲染、也可直接导入的候选列表。 */
    search(query: string, limit?: number): Promise<ModelCandidate[]>;
    /** 取单件元数据。 */
    get(partId: string): Promise<ModelCandidate>;
    /**
     * 下载某件的 GLB。
     *
     * ★ **两道闸门，量的是不同的东西**：
     *   ① 预检：`byteSize`（**STEP** 大小）≤ {@link StepPartsClientOptions.precheckBytes} —— 只挡明显离谱的
     *   ② 实检：下载后的**实际字节数** ≤ {@link StepPartsClientOptions.maxBytes} —— 这才是真正的闸门
     *
     *   不能用 `byteSize` 直接卡 `maxBytes`：它量的是 STEP，而 GLB 通常小一个数量级
     *   （实测树莓派 4B：STEP 50.1MB → GLB 5.7MB）。那样会拒掉一大批其实装得下的件。
     *
     * ★ 下载后用**内容**校验（GLB 魔数），不信 content-type、不信扩展名。
     */
    download(partId: string): Promise<{
        bytes: Buffer;
        candidate: ModelCandidate;
    }>;
}
