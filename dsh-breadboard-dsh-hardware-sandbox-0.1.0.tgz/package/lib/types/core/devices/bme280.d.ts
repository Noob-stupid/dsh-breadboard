/**
 * BME280 寄存器级行为模型（设计文档 §5.2）
 * @module dsh-hardware-sandbox/core/devices/bme280
 *
 * ★ 这是 §3.2「语义等价」真正被考验的地方。判据是三条：**结果一致 / 路径覆盖 / 异常一致**。
 *
 * ── 核心设计决策：物理真值 + **数值反解** ──
 *
 * 设备内部存的是**物理量**（温度 °C、湿度 %RH、气压 Pa），因为 `tick(dt)` 做漂移时
 * 物理量才是自然的自变量。
 *
 * 但项目读到的必须是**原始 ADC**（20 位/16 位），因为真实项目会自己套一段
 * Bosch 补偿算法把它换算成物理量。所以读出时要**反解**：求 `adc` 使得
 * `补偿(adc) == 我们的物理值`。
 *
 * 为什么值得这么做（而不是直接返回"算好的物理值"）：
 *   项目代码里那段补偿算法（读 26 字节校准 + 做定点运算）**必须真的被执行到**。
 *   如果我们返回算好的值，项目的补偿分支就成了死代码 —— 而它在真实硬件上是要跑的。
 *   反解之后，**项目自己算出来的**就是我们的物理值，这才是「结果一致性」的硬证据。
 *
 * 反解用**二分法**：补偿函数在各自区间内单调，24 次迭代足以覆盖 20 位量程。
 * 读操作相对 tick 很稀疏，这点计算量可以忽略。
 *
 * ── 覆盖的路径（对应 §3.2 的「路径覆盖」）──
 *   · 芯片 ID / 复位值 / 状态寄存器
 *   · **26 字节校准寄存器**（做补偿的项目必读）
 *   · 湿度校准的 0xE1–0xE7 非连续布局（很多手写驱动在这里翻车）
 *   · ctrl_meas / ctrl_hum / config 写入
 *   · 软复位
 *   · 强制模式下的 measuring 状态位
 */
import type { DeviceFault, DeviceSnapshot, I2CReadRequest, I2CReadResult, I2CWriteRequest, VirtualDevice } from '../../contracts/device.ts';
import type { TickContext } from '../../contracts/time.ts';
/**
 * 校准系数。
 *
 * ★ 默认值取 **Bosch 数据手册的示例值** —— 好处是可以用手册里给出的
 *   期望输出做交叉验证（见 tests/bme280.test.ts），比自造数据可信得多。
 */
export interface Bme280Calibration {
    readonly digT1: number;
    readonly digT2: number;
    readonly digT3: number;
    readonly digP1: number;
    readonly digP2: number;
    readonly digP3: number;
    readonly digP4: number;
    readonly digP5: number;
    readonly digP6: number;
    readonly digP7: number;
    readonly digP8: number;
    readonly digP9: number;
    readonly digH1: number;
    readonly digH2: number;
    readonly digH3: number;
    readonly digH4: number;
    readonly digH5: number;
    readonly digH6: number;
}
/** Bosch 数据手册 3.4 节的示例校准值。 */
export declare const DATASHEET_CALIBRATION: Bme280Calibration;
/** 温度补偿结果。`tFine` 是气压/湿度补偿必须的中间量。 */
export interface TemperatureResult {
    /** 中间量，气压与湿度补偿都要用。 */
    readonly tFine: number;
    /** 温度，单位 0.01 °C（"5123" = 51.23 °C）。 */
    readonly temperature: number;
}
/** 温度补偿。 */
export declare function compensateTemperature(cal: Bme280Calibration, adcT: number): TemperatureResult;
/** 气压补偿。返回 Q24.8 定点值（"24674867" = 96386.2 Pa）。 */
export declare function compensatePressure(cal: Bme280Calibration, adcP: number, tFine: number): number;
/** 湿度补偿。返回 Q22.10 定点值（"47445" = 46.333 %RH）。 */
export declare function compensateHumidity(cal: Bme280Calibration, adcH: number, tFine: number): number;
export interface Bme280Options {
    readonly id?: string;
    /** I2C 从机地址。默认 0x76（SDO 接 GND），与设计文档 §5.2 / §8 一致。 */
    readonly address?: number;
    /** 固定种子 —— 保证可复现（§0.4 P3 的要求）。 */
    readonly seed?: number;
    /** 校准系数。默认取数据手册示例值。 */
    readonly calibration?: Bme280Calibration;
    /** 初始温度（°C）。 */
    readonly temperature?: number;
    /** 初始相对湿度（%RH）。 */
    readonly humidity?: number;
    /** 初始气压（Pa）。 */
    readonly pressure?: number;
    /**
     * 每个时间片的漂移幅度倍率。
     * 设 0 可得到**完全静止**的传感器（测试用），此时读数只由初始值决定。
     */
    readonly driftScale?: number;
}
export declare class VirtualBME280 implements VirtualDevice {
    #private;
    readonly id: string;
    readonly kind: "sensor";
    readonly address: number;
    readonly calibration: Bme280Calibration;
    constructor(options?: Bme280Options);
    get temperature(): number;
    get humidity(): number;
    get pressure(): number;
    /**
     * 按时间片漂移物理量。
     *
     * ★ 必须返回 `nextEventIn() === null`（需要每一个时间片）：
     *   漂移是**积分型**的，结果与 tick 次数相关，跳空会改变结果（见 virtual-clock.ts 的取舍说明）。
     */
    tick(ctx: TickContext): void;
    /** 积分型模型：需要每一个时间片。 */
    nextEventIn(): number | null;
    onI2CRead(request: I2CReadRequest): I2CReadResult;
    onI2CWrite(request: I2CWriteRequest): void;
    injectFault(fault: DeviceFault): void;
    snapshot(): DeviceSnapshot;
}
