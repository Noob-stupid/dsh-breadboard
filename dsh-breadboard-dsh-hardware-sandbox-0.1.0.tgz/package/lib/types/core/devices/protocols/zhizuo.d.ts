/**
 * 智座座位传感器协议适配器
 * @module dsh-hardware-sandbox/core/devices/protocols/zhizuo
 *
 * 对应项目：`D:\MAX_xiangmu`（Flask + SocketIO 的「智能选座与导航一体化系统」）。
 * 真机是「每个座位一个 ESP32 + 双红外」，按周期把读数 HTTP 上报。
 *
 * ══════════════════════════════════════════════════════════════════════════
 * ★ 本文件里的每一条约定都是**从 app.py 读出来的**，不是推测的
 * ══════════════════════════════════════════════════════════════════════════
 *
 * | 约定 | 出处 |
 * |---|---|
 * | 统一信封 `{code, message, data}` | `api_response()`（app.py:270） |
 * | **HTTP 状态码 == `code`** | `return jsonify({...}), code` —— 所以 4xx 会真的抛 |
 * | 注册：`POST /api/sensor/device/register {device_id}` | app.py:3966 |
 * | 拉配置：`GET /api/sensor/device_config?device_id=` | app.py:3989 |
 * | 上报：`POST /api/sensor/report {seat_id, ir_front, ir_back}` | app.py:2075 |
 * | 上报返回**状态机的答复** `{seat_id, status, consecutive_empty}` | app.py:2185 |
 * | 配置字段：`ir_active_high` / `report_interval_ms` / `sensor_type` / `seat_id` … | `_device_config_payload()`（app.py:3950） |
 *
 * ── 两个**不报错但会做错**的地方（都编码在这里） ──
 *
 * ① **上报必须带 `device_id`，否则设备在线心跳不刷新。**
 *    app.py:2174 原文：`dev_id = data.get('device_id'); if dev_id: sdev.last_seen = now`。
 *    不带的话，设备**看起来**一直在上报，但面板上会显示"离线" ——
 *    因为在线判定读的是 `last_seen`。这是一个纯粹的静默失败。
 *
 * ② **`ir_active_high` 决定"遮挡时读到 1 还是 0"。**
 *    我们模拟的是**物理遮挡**，翻译成原始电平是**协议侧**的责任。
 *    搞反的症状是"**人坐下反而释放**"，且不报任何错。
 *
 * ── 状态机的一个关键行为（影响场景怎么写） ──
 *
 * 释放需要**连续 2 次空**（app.py:2144 `consecutive_empty >= 2`）。
 * ⇒ 只报一次空**不会**释放。这不是 bug，是真机行为，工具与文档必须如实说明。
 */
import type { NetworkProtocolAdapter } from '../../../contracts/network.ts';
export declare const ZHIZUO_PROTOCOL_ID = "zhizuo-sensor";
export declare const zhizuoSensorAdapter: NetworkProtocolAdapter;
