/**
 * DeterministicTestDevice —— 验收专用确定性设备（设计文档 §0.4 P3）
 * @module dsh-hardware-sandbox/core/devices/deterministic
 *
 * 设计文档给的原型是「每次 tick 就 +1」。**那个原型与 §7.3 的时钟设计自相矛盾**，
 * 必须修正，否则 P3 的断言 `readings == [1,2,3,4,5]` 永远不可能成立：
 *
 *   若 `tick` 每次 +1，而 `advance(1.0)` 在 step=1ms 下要 tick **1000 次**，
 *   则第一次读数就是 1000，五次读数会是 [1000, 2000, 3000, 4000, 5000]。
 *
 * 本实现的修正（两条，都是把「说不清」变成「说得清」）：
 *
 * ① **按采样周期结转而非按 tick 计数**：设备累加的是虚拟时间，每满 `period` 秒
 *    产生一次采样。`advance(1.0)` 恰好推进 1.0 秒 → 恰好 +1 次采样。
 *    定义文档的 `readings == [1,2,3,4,5]` 因此**逐字成立**。
 *
 * ② **初值为 1 而非 0**：文档的测试循环是「先读、后睡」——
 *    第 1 次读发生在任何 sleep 之前。真实传感器上电即产出首个有效读数，
 *    所以 t=0 时已有第 1 个采样，初值为 1 是**物理正确**的，不是凑数。
 *
 * 副产品：这个修正让 P3 变成一条**更强的**判据 —— 它同时验证了
 * 「1000 个 1ms 时间片必须精确累加为 1.0 秒」（整数微秒时钟的核心性质）。
 */
import type { DeviceFault, DeviceSnapshot, I2CReadRequest, I2CReadResult, I2CWriteRequest, VirtualDevice } from '../../contracts/device.ts';
import type { TickContext } from '../../contracts/time.ts';
import { MICROS_PER_SECOND } from '../../contracts/time.ts';
export interface DeterministicDeviceOptions {
    readonly id?: string;
    /** 采样周期（秒）。默认 1.0 —— 与文档测试的 `sleep(1)` 对齐。 */
    readonly period?: number;
    /** I2C 从机地址。默认 0x48。 */
    readonly address?: number;
    /** t=0 时已有几个采样。默认 1（上电即有首读）。 */
    readonly initialSamples?: number;
}
export declare class DeterministicTestDevice implements VirtualDevice {
    #private;
    readonly id: string;
    readonly kind: "test";
    readonly address: number;
    constructor(options?: DeterministicDeviceOptions);
    /** 当前采样序号（1 基）。 */
    get samples(): number;
    /** 被 tick 的次数。 */
    get tickCount(): number;
    get status(): DeviceSnapshot['status'];
    /**
     * 由 `ctx.nowMicros` **绝对推导**采样序号，而不是累加 `ctx.delta`。
     *
     * 这样做的收益：即使时钟因为加速跳空而漏掉若干 tick（本设备不会，
     * 但契约允许），采样序号也不会累计漂移 —— 它只是虚拟时刻的纯函数。
     */
    tick(ctx: TickContext): void;
    /**
     * ★ 永远返回 `null`：本设备**需要每一个时间片**。
     *
     * 这是刻意的 —— 它的职责就是当「时间片无丢失」的探针（T3）。
     * 若它声明可跳空，`tickCount` 就会小于片数，探针失效。
     * 积分型行为模型（如 BME280 的随机漂移）同理必须返回 null。
     */
    nextEventIn(): number | null;
    /**
     * I2C 读。地址不匹配返回 `null`（交给总线上下一个设备，**不是错误**）。
     * 读数按**大端**编码进 `length` 字节 —— shim 侧按同一约定解码。
     */
    onI2CRead(request: I2CReadRequest): I2CReadResult;
    onI2CWrite(_request: I2CWriteRequest): void;
    injectFault(fault: DeviceFault): void;
    snapshot(): DeviceSnapshot;
}
export { MICROS_PER_SECOND };
