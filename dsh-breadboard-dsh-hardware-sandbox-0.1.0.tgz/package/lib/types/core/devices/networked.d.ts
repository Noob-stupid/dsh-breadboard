/**
 * NetworkedDevice —— 联网设备运行时（第二类虚拟硬件）
 * @module dsh-hardware-sandbox/core/devices/networked
 *
 * ══════════════════════════════════════════════════════════════════════════
 * ★ 为什么它**不是** `VirtualDevice`
 * ══════════════════════════════════════════════════════════════════════════
 *
 * `VirtualDevice.tick` 的契约原文是「**必须纯同步、无 IO、无真随机**」。
 * 联网设备天生做 IO 且不可确定（对面是真服务器）⇒ **结构上不可能**是它。
 * 详见 `contracts/network.ts` 的长注释（含"为什么驱动源必须是墙钟"）。
 *
 * ══════════════════════════════════════════════════════════════════════════
 * ★ 全部逻辑都在 `reportOnce()` 里，循环只是薄壳
 * ══════════════════════════════════════════════════════════════════════════
 *
 * 这是**为可测性做的结构性选择**：若把逻辑埋在定时器回调里，测试就只能
 * 「等真实时间过去」—— 慢、不稳、且失败时看不出是哪一步错的。
 * 现在测试直接调 `reportOnce()`，**不碰定时器、不碰网络**（传输是注入的）。
 * `start()` 里的循环因此可以短到一眼看完。
 */
import type { JsonRecord, NetworkBinding, NetworkDeviceSnapshot, NetworkDeviceStatus, NetworkProtocolAdapter, NetworkTransport } from '../../contracts/network.ts';
import type { DeviceFault, DeviceSnapshot } from '../../contracts/device.ts';
export interface NetworkedDeviceOptions {
    readonly id: string;
    readonly label: string;
    readonly binding: NetworkBinding;
    readonly adapter: NetworkProtocolAdapter;
    readonly transport: NetworkTransport;
    /** 初始物理读数（键见 `adapter.readingKeys`）。 */
    readonly reading?: JsonRecord;
    /** 每多少次上报拉一次配置（智座"改配置免重烧"靠它）。默认 10。 */
    readonly configPullEveryCycles?: number;
    /** 墙钟来源，可注入以便测试。 */
    readonly now?: () => number;
    /** 定时器注入 —— 测试不必真的等。 */
    readonly setTimer?: (callback: () => void, ms: number) => unknown;
    readonly clearTimer?: (handle: unknown) => void;
    /** 状态变化通知（由注册表用来把快照发布回 SSOT）。 */
    readonly onChange?: () => void;
}
export declare class NetworkedDevice {
    #private;
    readonly id: string;
    constructor(options: NetworkedDeviceOptions);
    get status(): NetworkDeviceStatus;
    get running(): boolean;
    snapshot(): NetworkDeviceSnapshot;
    /**
     * 投影成通用 {@link DeviceSnapshot} —— 让它与总线设备**进同一份 SSOT**。
     *
     * ★ `transport: 'network'` 是关键：两者时刻语义不同，前端必须能区分。
     */
    toDeviceSnapshot(): DeviceSnapshot;
    /** 设置物理读数（如 `{ ir_front: true, ir_back: true }` = 有人）。 */
    setReading(reading: JsonRecord): void;
    /**
     * 开机：注册 → 进入周期上报。
     *
     * ★ 注册失败**不抛**：设备会保持 `error` 状态并继续重试 ——
     *   真机也是这样（对面没起来不该让整个沙盒崩掉）。
     *   但状态是**可见的**（`status='error'` + `lastError`），不是静默吞掉。
     */
    start(): Promise<void>;
    stop(): void;
    /** 注册（或重新注册）。 */
    register(): Promise<boolean>;
    /** 拉一次配置。 */
    pullConfig(): Promise<boolean>;
    /**
     * 上报一次。**这是全部逻辑所在**（循环只是薄壳，测试直接调它）。
     *
     * @returns 是否成功
     */
    reportOnce(): Promise<boolean>;
    /** 故障注入（对应工具 `hw_inject_fault`）。 */
    injectFault(fault: DeviceFault): void;
}
