/**
 * AssemblyState —— 装配状态（SSOT）· 设计文档 §6.1
 * @module dsh-hardware-sandbox/core/state/assembly-state
 *
 * ★ 单一真相源。三 realm 里**只有宿主持有它**：
 *   浏览器是它的投影（§4.2.4「场景是状态的投影，不是副本」），
 *   Python shim 是它的代理（连快照都没有）。
 *
 * ★ 一条刻意的设计决策：**端口占用不落在 Port 上，而是从 connections 推导**。
 *   契约里 `Port.occupiedBy` 是可选字段，但本类**不维护**它 —— 快照生成时才填。
 *   理由：若同时在 `ports[].occupiedBy` 和 `connections` 里记一份占用关系，
 *   就是第二本账，两者一旦不同步，视觉仲裁拿到的「事实」就是错的。
 *   ⇒ 占用关系只有 connections 一个出处。
 */
import type { AssemblySnapshot, ComponentSpec, ConnectionSpec, PortRef, PowerSummary, Vec3, Warning, WarningCode } from '../../contracts/assembly.ts';
import type { DeviceSnapshot, Protocol } from '../../contracts/device.ts';
import type { NetworkBinding } from '../../contracts/network.ts';
import { type ProjectProfile } from '../../contracts/projects.ts';
import type { ActionResult, ClientAction } from '../../contracts/protocol.ts';
/** 状态变更结果。失败时带可读原因码（复用 WarningCode）。 */
export type StateResult<T> = {
    readonly ok: true;
    readonly value: T;
} | {
    readonly ok: false;
    readonly reason: WarningCode;
};
export declare class AssemblyState {
    #private;
    get revision(): number;
    /**
     * 订阅**结构性变更**（放置/移除/移动/连线/拔线/重置）。
     *
     * ★ 虚拟设备发布（{@link setVirtualDevices}）**不**触发订阅者 —— 否则
     *   「设备注册表监听变更 → 发布设备快照 → 又触发变更」会形成死循环。
     *   revision 仍会递增（前端要靠它做 diff），只是不通知结构性订阅者。
     */
    onChange(listener: () => void): () => void;
    get components(): readonly ComponentSpec[];
    get connections(): readonly ConnectionSpec[];
    findComponent(componentId: string): ComponentSpec | undefined;
    findConnection(cableId: string): ConnectionSpec | undefined;
    /**
     * 主线 B 写入**总线设备**状态（`DeviceRegistry` 用）。
     *
     * ★ 只递增 revision、**不通知结构性订阅者** —— 见 {@link onChange} 的说明。
     *
     * ⚠️ **只写总线这一半**。联网设备走 {@link setNetworkDevices}。
     *   早先只有这一个 setter，若两个注册表都调它，**后写的会把先写的整个覆盖掉** ——
     *   而症状是"设备时有时无"，取决于谁后跑。⇒ 拆成两个字段，**各自只有一个写者**。
     */
    setVirtualDevices(devices: readonly DeviceSnapshot[]): void;
    /**
     * 写入**联网设备**状态（`NetworkRegistry` 用）。
     *
     * ★ 与 {@link setVirtualDevices} 是两个字段、两个写者，互不覆盖；
     *   对外仍在 `snapshot().virtualDevices` 里**合并成一份**（单一 SSOT，§6.1）。
     *   这是「所有权唯一」与「一份真相」同时满足的写法。
     */
    setNetworkDevices(devices: readonly DeviceSnapshot[]): void;
    /**
     * 放置组件。位置单位米（§4.2.1）。
     *
     * @param options.network —— 见 `contracts/network.ts`。给了它就是一台**联网设备**。
     *   ★ 用可选对象而不是第 4 个位置参数：调用方常常只想给 id 不给 network，
     *     位置参数会逼出 `place(m, p, 'x', undefined)` 这种读不懂的调用。
     */
    /**
     * **把联网绑定挂到一台已经放好的组件上**（而不是新放一台）。
     *
     * ★ 为什么需要它 —— 这是"硬件在环"能不能成立的关键一环：
     *   真机里**那台 ESP32 本身就是座位传感器**：PIR 接在它的 GPIO 上，它自己出网上报。
     *   如果联网设备必须是**另一个**组件，那么"遮挡装配里的 PIR"就永远传不到它身上
     *   —— 接线关系断了，整个 `hw_set_occlusion` 就没有意义。
     *
     * ★ 只允许挂到**还没有绑定**的组件上：覆盖已有绑定会让"这台接的是哪个系统"
     *   变成一个可以被随手改掉的字段，而端点/设备号是**已经在跑**的东西。
     *   要改就先解绑（未来若有需要再加），**不要让它静默换掉**。
     */
    setNetwork(componentId: string, network: NetworkBinding): StateResult<ComponentSpec>;
    place(hardwareModel: string, position: Vec3, id?: string, options?: {
        readonly network?: NetworkBinding;
    }): StateResult<ComponentSpec>;
    /** 移除组件，并连带移除挂在它身上的全部线缆。 */
    remove(componentId: string): StateResult<{
        removedCables: string[];
    }>;
    /**
     * 移动组件。位置单位米。
     *
     * ★ **钉住的组件拒绝移动**，且是**明确失败**（带原因），不是静默忽略。
     *   拦截落在这里而不是 UI 层 —— 因为移动走的是 action 路由，
     *   DS / 另一个客户端 / 脚本都从这条路进来。**只拦鼠标不叫锁。**
     */
    move(componentId: string, position: Vec3): StateResult<ComponentSpec>;
    /**
     * 钉住 / 解开一个组件。
     *
     * ★ 幂等：`pinned` 已是目标值时**不递增 revision**（避免无意义的场景重调和）。
     */
    setPinned(componentId: string, pinned: boolean): StateResult<ComponentSpec>;
    /**
     * **导入一个软硬件项目**：按图纸清场、放器件、连线、挂联网绑定。
     *
     * ★ 先**清空**再摆：导入的语义是"**把现场布置成这张图纸**"，不是"往上加"。
     *   不清空的话，同一个项目导两次会因为 id 撞车而失败，症状是
     *   「第一次好好的，再点一次就报错」—— 很难懂。
     *
     * ★ 放在 SSOT 而不是工具里：**界面切换项目和 agent 调工具必须是同一条路**。
     *   各写一份，迟早一个能切一个不能，而没人知道差在哪。
     *
     * ⚠️ 中途失败**不回滚已经放下的器件**：如实返回失败原因。
     *   回滚看着更干净，但会把"到底哪一步断的"抹掉 —— 而**这个项目现在是断的**，
     *   用户必须知道（这正是本项目失败族里那条：可见的失败 > 静默的干净）。
     */
    importProject(project: ProjectProfile): StateResult<readonly string[]>;
    /**
     * **旋转一个组件**（欧拉角，弧度，绕**自身原点** = 几何包围盒中心）。
     *
     * ★★ 为什么"绕中心转"是这条链能不能用的关键 —— 契约里那条原点约定就是为它定的：
     *   > `position` 是**包围盒中心**，不是角点。取「居中」而非 CAD 惯用的「min 角」，
     *   > **决定性理由是旋转枢轴**：原点在角上，组件一转就会**绕角甩出去**。
     *   ⇒ 所以 `setRotation` **不需要**顺带改 `position`：原点居中的模型转起来是原地转，
     *     位置语义（"它摆在哪"）保持不变。
     *
     * ★ 与 `setPinned` 同样幂等：角度没变就不递增 revision。
     *   比较用**容差**，因为调用方常常从界面拖动里传来浮点数（`1.5707963267948966` vs `1.5707963`），
     *   精确相等会把"同一个角度"当成两次修改，**每次指针移动都重建一次场景**。
     */
    setRotation(componentId: string, rotation: Vec3): StateResult<ComponentSpec>;
    /** 连线。校验不通过时返回失败原因，且**不改动状态**。 */
    connect(from: PortRef, to: PortRef): StateResult<ConnectionSpec>;
    /** 拔出线缆。 */
    disconnect(cableId: string): StateResult<{
        cableId: string;
    }>;
    /** 执行一个来自前端的动作（`POST /api/action`）。 */
    applyAction(action: ClientAction): ActionResult;
    /**
     * 连线校验。顺序与设计文档 §6.2 的 `validateConnection` 一致：
     * 协议 → 占用 → 电平 → 供电预算。
     */
    validateConnection(from: PortRef, to: PortRef): {
        ok: true;
        protocol: Protocol;
    } | {
        ok: false;
        reason: WarningCode;
    };
    powerSummary(): PowerSummary;
    /** L1 拓扑与电气检查产生的警告。 */
    warnings(): Warning[];
    /**
     * 生成快照 —— 前端场景渲染的唯一输入。
     *
     * ★ 端口占用在这里才填进 `occupiedBy`（从 connections 推导），
     *   保证快照里的占用关系与 connections 永远一致。
     */
    snapshot(): AssemblySnapshot;
    /** 清空（保留计数器，保证同一次会话内 id 不复用）。 */
    reset(): void;
}
