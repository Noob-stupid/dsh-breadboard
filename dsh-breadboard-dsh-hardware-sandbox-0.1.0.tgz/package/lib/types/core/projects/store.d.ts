/**
 * **项目存储** —— 用户自己的软硬件项目（默认**空**）。
 * @module dsh-hardware-sandbox/core/projects/store
 *
 * ══════════════════════════════════════════════════════════════════════════
 * ★★ 为什么从"硬编码常量"改成"用户文件"
 * ══════════════════════════════════════════════════════════════════════════
 *
 * 第一版把智座写死在 `SAMPLE_PROJECTS` 里。用户的原话把问题说透了：
 *
 *   > **别人的插件应该是自己添加项目才对，而不是我们这个懂吗，
 *   > 别人是自己导入他们的项目，是空的**
 *
 * 对的。**智座是我们的演示，不是别人的项目。** 把我们的东西硬编码进插件，
 * 等于告诉所有用户"你只能跑这一个系统" —— 而这是个**沙盒**。
 *
 * ⇒ 项目改成**用户目录里的 JSON**（与 `ModelStore` 同一手法）：
 *   · 新用户打开是**空的**
 *   · 别人**导入/添加自己的**项目
 *   · 智座降级成 `examples/zhizuo-seat-node.json` —— **一份可以导入的样例**，不是内置项
 *
 * ══════════════════════════════════════════════════════════════════════════
 * ★ 为什么与 ModelStore 分开，而不是塞进同一个目录
 * ══════════════════════════════════════════════════════════════════════════
 *
 * 两者形状像（都是"用户目录 + 一堆文件"），但**生命周期完全不同**：
 *   模型 = 二进制 GLB，可能几 MB，导入一次基本不动；
 *   项目 = 小 JSON，**会被 agent 反复改**（加个器件、换个引脚）。
 * 混在一起，`清空模型` 之类的操作会**顺手把项目也删了**，而那时没人会想到。
 */
import { type ProjectProfile } from '../../contracts/projects.ts';
import type { NetworkBinding } from '../../contracts/network.ts';
/** 存储错误的原因码。**给人看的原因**由调用方拼，这里只给机器可判定的。 */
export type ProjectStoreErrorCode = 'bad_id' | 'not_found' | 'io' | 'bad_json' | 'bad_shape';
export declare class ProjectStoreError extends Error {
    readonly code: ProjectStoreErrorCode;
    constructor(code: ProjectStoreErrorCode, message: string);
}
export interface ProjectStoreOptions {
    /** 项目目录（`~/.dsh/dsh-hardware-sandbox/projects`）。 */
    readonly root: string;
    /** 本体快照目录。省略则 `<root>/../bodies`。 */
    readonly bodiesRoot?: string;
}
/**
 * 校验一份**用户给的**项目定义。
 *
 * ★★ 为什么必须校验：图纸可能是**用户从文件选的**（手写、别人给的、agent 生成的），
 *   **不受我们控制**。少了这一步，坏数据会一路走到 `importProject` ——
 *   那时的表现是「**导入成功，但场景里什么都没有**」，而调用方只看到 `ok:true`。
 *   ⇒ 能判的都在**入口**判掉，并且**说清是哪一种坏**。
 *
 * ⚠️ 判的是**能不能用**，不是"完不完美"：多出来的字段一律保留
 *   （不认识的字段不该让导入失败 —— 那会把"格式演进"变成"旧文件全废"）。
 */
export declare function validateProjectProfile(raw: unknown): {
    ok: true;
    profile: ProjectProfile;
} | {
    ok: false;
    reason: string;
};
/**
 * **把当前装配抓成一份项目图纸** —— "保存现有建模"的核心。
 *
 * ★★ 用户原话：「关键是在**哪把现有建模导出保存**」
 *
 *   在此之前只能**导入**图纸，**导不出去** —— 用户在场景里摆好、连好之后，
 *   没有任何办法把它存下来。**这等于"能看不能存"**，而"存"才是他真正要的。
 *
 * ★ 抓的是**当前场景**，不是项目文件里那份：
 *   用户可能刚挪了器件、加了根线、换了个朝向 —— 那些**都在装配状态里**。
 *   从文件里读等于把用户刚才做的事**全部丢掉**。
 *
 * ⚠️ `label` / `description` / `link` 这些**图纸元信息不在装配里**，
 *   所以从 `base`（项目原有的定义）继承；只覆盖**几何与连接**那几项。
 */
export declare function captureProject(base: ProjectProfile, snapshot: {
    readonly components: readonly {
        readonly id: string;
        readonly hardwareModel: string;
        readonly position: {
            readonly x: number;
            readonly y: number;
            readonly z: number;
        };
        readonly rotation: {
            readonly x: number;
            readonly y: number;
            readonly z: number;
        };
        readonly network?: NetworkBinding;
    }[];
    readonly connections: readonly {
        readonly from: {
            readonly componentId: string;
            readonly portId: string;
        };
        readonly to: {
            readonly componentId: string;
            readonly portId: string;
        };
    }[];
}): ProjectProfile;
/**
 * **项目本体快照** —— 用户导入的那个**真实项目文件夹**留下的一份记录。
 *
 * ★★ 用户原话：
 *   > 这个上传项目本体，你**上传后那得显示项目啊**，
 *   > 那个扫描可以**后续扫描按钮**，**先上传项目到那里**
 *
 *   ⇒ 两步分开：**先上传（进列表）**，**再扫描（按钮）**。
 *     而不是"一上传就扫、扫完就没影了"。
 *
 * ★ 为什么要把文本样本**存下来**：扫描要读文件内容，而浏览器**不会再给一次**
 *   （用户不会再选一遍文件夹）⇒ 不存就只能当场扫完。
 *   样本有总预算（180KB），存下来完全可行。
 *
 * ★ 为什么不存**整个文件夹**：真实项目可能几百 MB（node_modules…），
 *   而扫描要的只是**配置与文档**。存整个文件夹既没必要，也会把磁盘吃光。
 */
export interface ProjectBody {
    readonly id: string;
    readonly label: string;
    /** 用户选的那个文件夹的名字（如 `MAX_xiangmu`）—— 列表里要显示它。 */
    readonly source: string;
    readonly importedAt: string;
    /** 这个文件夹里一共有多少文件（**全部**，不只是被采样的）。 */
    readonly fileCount: number;
    /** 采样的文本文件（受总预算限制）。 */
    readonly files: readonly {
        readonly path: string;
        readonly text: string;
    }[];
    /** 因为预算被跳过的文件数（如实记，别让人以为全扫过了）。 */
    readonly skipped: number;
    /** 最后一次扫描的结果（没扫过就是 `undefined`）。 */
    readonly report?: ProjectScanOutcome;
}
/** 一次扫描的结论。 */
export interface ProjectScanOutcome {
    readonly at: string;
    readonly matched: readonly {
        readonly modelKey: string;
        readonly label: string;
        readonly hasGeometry: boolean;
        readonly evidence: readonly string[];
    }[];
    readonly missingGeometry: readonly string[];
}
export declare class ProjectStore {
    #private;
    readonly root: string;
    /**
     * 本体快照的目录 —— **与项目定义分开**。
     *
     * ★ 分开的理由不是洁癖：`list()` 会把 `root` 下每个 `.json` 当成一份**项目定义**。
     *   本体快照的形状完全不同（有 `files` 数组）⇒ 混在一起，`list()` 会把它们
     *   读成"坏文件"，列表里冒出一堆莫名其妙的红字。
     */
    readonly bodiesRoot: string;
    constructor(options: ProjectStoreOptions);
    listBodies(): Promise<{
        bodies: ProjectBody[];
        broken: string[];
    }>;
    getBody(id: string): Promise<ProjectBody | undefined>;
    saveBody(body: ProjectBody): Promise<void>;
    removeBody(id: string): Promise<boolean>;
    /**
     * 列出全部项目。
     *
     * ★ **目录不存在 = 返回空数组，不是报错** —— 新用户就是没有项目，
     *   那不是"出错了"。报错会让界面显示一条红字，而其实一切正常。
     * ★ 单个文件坏了**只跳过它**，不影响别的：一个手写的坏 JSON
     *   不该让整个项目列表消失。
     */
    list(): Promise<{
        projects: ProjectProfile[];
        broken: string[];
    }>;
    get(projectId: string): Promise<ProjectProfile | undefined>;
    save(profile: ProjectProfile): Promise<void>;
    remove(projectId: string): Promise<boolean>;
    /**
     * **把随包样例装进用户目录**（用户明确要导入时才调）。
     *
     * ⚠️ 与 `seedPackagedModels` **不同**：那个是启动时自动补齐（模型是"基础设施"），
     *   这个是**用户显式导入**（项目是"他的东西"）。
     *   ⇒ 新用户的项目列表**默认是空的**，这正是用户要的。
     */
    importSample(projectId: string): Promise<ProjectProfile | undefined>;
}
