/**
 * NetworkRegistry —— 把**装配状态**与**联网设备**接起来
 * @module dsh-hardware-sandbox/core/sim/network-registry
 *
 * 与 `DeviceRegistry` 是**并列**的两件事，不是它的扩展：
 * 那个管"等被读"的总线设备（虚拟时钟驱动），这个管"主动出网"的联网设备（墙钟驱动）。
 *
 * ══════════════════════════════════════════════════════════════════════════
 * ★★ 关键安全决定：**放进来 ≠ 开始发请求**
 * ══════════════════════════════════════════════════════════════════════════
 *
 * 总线设备放进场景就"活着"是**无害的** —— 它只是等着被读，不产生任何副作用。
 *
 * **联网设备不是**。它一旦启动就**真的往外发 HTTP**：
 *   · 用户拖一个组件进场景，不该因此让某个真实服务器开始收包
 *   · 更不该在用户没注意时**持续**收包（间隔由对面配置，可能是 1 秒）
 *
 * ⇒ 放进来的设备停在 `idle`，**必须显式启动**（工具 / 界面按钮）。
 *   这条不是保守，是"**默认不该有外部副作用**"。
 *
 * ★ 与 `DeviceRegistry` 同样的订阅式调和：手动 sync 一旦有人忘了调，
 *   装配与设备就**静默漂移**，而现场表现为"明明放上去了却没有这台设备"。
 */
import type { ComponentSpec } from '../../contracts/assembly.ts';
import type { NetworkProtocolAdapter, NetworkTransport } from '../../contracts/network.ts';
import type { AssemblyState } from '../state/assembly-state.ts';
import { NetworkedDevice } from '../devices/networked.ts';
/**
 * 内置协议适配器表。
 *
 * ★ 加一个新协议 = 在这里加一行，**不动内核**。这是这条线可扩展的唯一原因。
 */
export declare const DEFAULT_NETWORK_ADAPTERS: Readonly<Record<string, NetworkProtocolAdapter>>;
export interface NetworkRegistryOptions {
    readonly state: AssemblyState;
    /** 出网能力（宿主半给真实 fetch，测试给假的）。 */
    readonly transport: NetworkTransport;
    /** 覆盖默认适配器表（测试用）。 */
    readonly adapters?: Readonly<Record<string, NetworkProtocolAdapter>>;
    /** 定时器/墙钟注入（测试用），透传给每台设备。 */
    readonly now?: () => number;
    readonly setTimer?: (callback: () => void, ms: number) => unknown;
    readonly clearTimer?: (handle: unknown) => void;
}
export declare class NetworkRegistry {
    #private;
    constructor(options: NetworkRegistryOptions);
    get deviceCount(): number;
    /** 当前创建失败的原因（componentId → 原因）。空 = 没有失败。 */
    get problems(): ReadonlyMap<string, string>;
    deviceFor(componentId: string): NetworkedDevice | undefined;
    /**
     * 按协议 id 取适配器。
     *
     * ★ 公开它的理由很具体：`hw_network_add` 建绑定时要把适配器的
     *   `defaultPinMap`（"`ir_front` 在 GPIO23"）**抄进这一台的绑定里**，
     *   而适配器表在这个类里面 ⇒ 不给访问器，工具就只能自己再维护一份协议表，
     *   那就是**第二本账**。
     */
    adapterFor(protocolId: string): NetworkProtocolAdapter | undefined;
    /** 全部联网设备（供工具与诊断遍历）。 */
    devices(): readonly NetworkedDevice[];
    /**
     * 按当前装配调和设备集合。
     *
     * ★ 与 `DeviceRegistry.sync` 一样是三步，但**没有第③步的 publish 收尾**：
     *   联网设备的状态是**异步变化**的（HTTP 回来才变），所以发布靠设备的
     *   `onChange` 回调，而不是靠调和这一刻的快照。调和只负责建/删。
     */
    sync(): void;
    /** 启动某台（或全部）设备。**这是唯一会让请求真正发出去的动作。** */
    start(componentId?: string): Promise<readonly NetworkedDevice[]>;
    /** 停止某台（或全部）。 */
    stop(componentId?: string): readonly NetworkedDevice[];
    dispose(): void;
}
/** 组件是不是联网设备（供工具/界面判断）。 */
export declare function isNetworkComponent(component: ComponentSpec): boolean;
