/**
 * VirtualClock —— 虚拟时钟调度器（设计文档 §7.3）
 * @module dsh-hardware-sandbox/core/vclock
 *
 * ★ 权威侧在宿主（JS/Node 内核）。Python 侧 `time.sleep` 经 shim 转发到本类的 `advance()`。
 *
 * 本实现相对设计文档 §7.3 伪码的三处强化（均来自定位文件 §3 的实测修正）：
 *
 * ① **整数微秒权威**：`0.001` 累加 1000 次在浮点下不等于 1.0。用整数微秒后累加精确，
 *    否则「逐次确定性读数」会在某个时刻多跳一格，P3/T1 会偶发红灯。
 *
 * ② **必须周期性让出宿主事件循环**（★ 新增判据 T6）：
 *    文档伪码是同步忙循环。`advance(1.0)` 在 step=1ms 下是 1000 次同步迭代，
 *    跑在宿主 Node 的事件循环上 —— 期间 DSH 自身（会话、UI 通信、其他插件）全部停摆。
 *    大步长下会明显卡顿甚至被误判为死机。本实现按**墙钟预算**让出：
 *    只有真正花掉 `yieldBudgetMs` 才 `await`，所以「算得快就不让出」（T5 不受损）、
 *    「算得久就让出」（T6 得到保证）。
 *
 * ③ **加速模式跳空**（代替文档所说的「事件优先队列」）：
 *    设备通过 `nextEventIn()` 声明「我下一个有意义的事件在 Δ 之后」。
 *    **只要有一台设备返回 null（需要每片），就绝不跳空** —— 积分型模型（如 BME280 漂移）
 *    的结果与片数相关，跳空会改变结果。这是安全性优先的取舍。
 */
import type { Micros } from '../../contracts/time.ts';
import { MICROS_PER_SECOND, microsToSeconds, secondsToMicros } from '../../contracts/time.ts';
import type { VirtualDevice } from '../../contracts/device.ts';
/** 参数非法或超出护栏时抛出。 */
export declare class VirtualClockError extends Error {
    constructor(message: string);
}
export interface VirtualClockOptions {
    /** 最小时间片（秒）。默认 0.001（1ms，同文档 §7.3）。 */
    readonly step?: number;
    /**
     * 宿主墙钟让出预算（毫秒）。默认 **1**。
     * 单次 `advance` 内累计消耗超过它就让出一次事件循环。
     * 设为 `0` 表示**从不让出** —— 仅供对照实验（T6 用它证明让出确实有效）。
     *
     * ★ 为什么默认是 1 而不是 4（实测：每片 20µs、`advance(10.0)`、10000 片）：
     *
     *   | 预算 | p50   | p95   | p99   | max   | 总耗时 |
     *   |-----:|------:|------:|------:|------:|-------:|
     *   |  0ms | 16.2  | 207.7 | 207.7 | 207.7 |  212ms |
     *   |  1ms |  1.04 |  1.19 |  2.20 |  16.0 |  220ms |
     *   |  2ms |  2.04 |  2.24 | 14.85 |  15.1 |  217ms |
     *   |  4ms |  4.06 |  9.18 | 15.07 |  15.1 |  217ms |
     *   |  8ms |  8.08 | 16.16 | 16.17 |  16.2 |  213ms |
     *
     *   两条结论：
     *   ① **p50 精确跟随预算** —— 让出机制按设计工作，预算就是典型阻塞时长。
     *   ② **max 有一个 ~16ms 的环境地板**，与预算无关（Node 定时器/GC 抖动），
     *      不是本时钟引入的系统性阻塞。⇒ 判据必须盯分位数，只盯 max 会把环境抖动
     *      误读成时钟缺陷。
     *
     *   4ms 预算的 p95 已达 9.18ms、p99 达 15ms，几乎吃掉一个 60fps 帧；
     *   1ms 预算的 p95 只有 1.19ms，代价仅 ~3% 总耗时（220ms vs 213ms）。
     *   对「realtime 模式要让人看得顺」的目标，1ms 明显更优。
     */
    readonly yieldBudgetMs?: number;
    /** 单次 advance 的虚拟时长上限（秒）。默认 3600，防跑飞。 */
    readonly maxAdvanceSeconds?: number;
    /** 让出事件循环的方式。默认 `setImmediate`；可注入以便测试。 */
    readonly yielder?: () => Promise<void>;
    /** 墙钟来源。默认 `performance.now()`；可注入以便测试。 */
    readonly wallNow?: () => number;
}
/** 单次推进的观测结果。 */
export interface AdvanceResult {
    readonly now: number;
    readonly nowMicros: Micros;
    /** 本次实际推进的虚拟时间（微秒）。 */
    readonly advancedMicros: Micros;
    /** 实际执行的 tick 片数。 */
    readonly slices: number;
    /** 本次让出事件循环的次数（T6 观测点）。 */
    readonly yielded: number;
    /** 本次的宿主墙钟耗时（毫秒）。 */
    readonly wallMs: number;
    /** 因跳空而**未**执行 tick 的虚拟时长（微秒）。 */
    readonly skippedMicros: Micros;
}
/** 时钟累计统计。 */
export interface ClockStats {
    readonly advanceCalls: number;
    readonly totalSlices: number;
    readonly totalYielded: number;
    readonly lastAdvanceWallMs: number;
    readonly maxAdvanceWallMs: number;
}
export declare class VirtualClock {
    #private;
    readonly stepMicros: Micros;
    readonly yieldBudgetMs: number;
    readonly maxMicrosPerAdvance: Micros;
    constructor(options?: VirtualClockOptions);
    /** 当前虚拟时刻（整数微秒）—— 权威值。 */
    get nowMicros(): Micros;
    /** 当前虚拟时刻（秒）—— 展示用视图。 */
    get now(): number;
    get deviceCount(): number;
    get stats(): ClockStats;
    /**
     * 注册设备。返回注销函数。
     * ★ 执行顺序 = 注册顺序（§7.3「同一时间片内按设备注册顺序确定性执行」）。
     */
    register(device: VirtualDevice): () => void;
    /** 注销设备。 */
    unregister(id: string): boolean;
    get(id: string): VirtualDevice | undefined;
    /** 按注册顺序返回设备（只读）。 */
    listDevices(): readonly VirtualDevice[];
    /** 全部设备快照，按注册顺序。 */
    snapshotDevices(): ReturnType<VirtualDevice['snapshot']>[];
    /** 归零虚拟时刻（不注销设备）。 */
    reset(): void;
    /**
     * 推进虚拟时间 `dt` 秒。
     *
     * 并发调用会被**串行化**（内部 Promise 链），不会交错推进设备状态。
     *
     * @param dt - 推进的虚拟时长（秒），必须 >= 0
     */
    advance(dt: number): Promise<AdvanceResult>;
}
/** 便于外部换算，避免各处重复 import。 */
export { MICROS_PER_SECOND, microsToSeconds, secondsToMicros };
