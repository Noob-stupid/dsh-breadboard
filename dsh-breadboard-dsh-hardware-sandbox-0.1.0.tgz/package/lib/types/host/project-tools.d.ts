/**
 * **项目导入工具** —— owner: session-24ca6e69
 * @module dsh-hardware-sandbox/host/project-tools
 *
 * ══════════════════════════════════════════════════════════════════════════
 * ★★ 它把"手工摆四步"压成一次调用，而且**顺带回答了"通了没有"**
 * ══════════════════════════════════════════════════════════════════════════
 *
 * 用户原话：
 *
 *   > 右上角对话框下面应该可以选择**导入软硬件项目**，比如举例子，
 *   > 你得知道**导入的是智座项目**，并且**软硬件连接通了得有显示**
 *
 * 在此之前要跑通智座得做四件事：放 ESP32 → 放两个 PIR → 连六根线 → 配联网绑定。
 * **少一步就不通，而每一步都不报错**（这正是本项目失败族里那条最贵的形状）。
 *
 * ══════════════════════════════════════════════════════════════════════════
 * ★ "通了"的判据**由项目自己定义**，内核只提供原始事实
 * ══════════════════════════════════════════════════════════════════════════
 *
 * 智座的"通"= 注册过 + 拉到过配置 + 成功上报过 + **最近一次也是成功的**。
 * 别的系统判据完全不同 ⇒ 判据写在 `ProjectProfile.link` 里，
 * 这里只负责把设备状态**翻译**成那几项事实。
 *
 * ⚠️ **`registered` 是推导出来的，不是直接读的** —— 见 {@link factsOf} 的说明。
 *   这一点必须写在代码里，否则下一个人会以为它是个真实字段。
 */
import { type ProjectProfile, type ProjectStatus } from '../contracts/projects.ts';
import { type HardwareToolDefinition } from './tools.ts';
import type { NetworkRegistry } from '../core/sim/network-registry.ts';
import type { AssemblyState } from '../core/state/assembly-state.ts';
import { type ProjectStore } from '../core/projects/store.ts';
export interface ProjectToolDeps {
    readonly state: AssemblyState;
    readonly registry: NetworkRegistry;
    /**
     * 用户的**项目存储**。
     *
     * ★ 项目是**用户自己的**（默认空），不是内置常量 —— 见 core/projects/store.ts。
     *   这里注入而不是 import 一个全局单例：测试能塞一个临时目录进去，
     *   不会碰用户真实的项目。
     */
    readonly projects: ProjectStore;
}
/**
 * **算一遍所有项目的当前状态** —— 工具与 HTTP 路由**共用这一份**。
 *
 * ★ 抽出来是为了**不出现第二本账**：界面看到的"连通"和 agent 看到的"连通"
 *   必须来自同一个函数。各算各的，迟早会一个说通、一个说没通，而没人知道信谁。
 *
 * ★ 项目清单**由调用方传进来**（来自 `ProjectStore`），不再读 `SAMPLE_PROJECTS` ——
 *   项目是**用户的**，不是内置的。见 `core/projects/store.ts` 的说明。
 */
export declare function projectStatuses(state: AssemblyState, registry: NetworkRegistry, profiles: readonly ProjectProfile[]): readonly ProjectStatus[];
export declare function createProjectTools(deps: ProjectToolDeps): HardwareToolDefinition[];
