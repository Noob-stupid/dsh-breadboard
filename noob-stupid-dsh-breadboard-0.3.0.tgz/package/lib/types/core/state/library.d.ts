/**
 * 硬件模型库（ModelLib 的 `schema/` 部分）—— 宿主内核
 * @module dsh-hardware-sandbox/core/state/library
 *
 * ★ 设计文档 §6.6：`ModelLib` 分 `geometry/`（几何模型，前端用）与 `schema/`（接口语义，**核心壁垒**）。
 *   本文件是 `schema/` 的宿主侧权威 —— 端口、协议、电平、地址、功耗都在这里。
 *
 * ★ 本期范围（§9.2）：只支持树莓派 + I2C + 单传感器。型号库刻意保持小。
 *   几何模型不由本文件负责（前端 `src/scene/` 按 `hardwareModel` 键加载）。
 */
import type { ComponentSpec, Port, Vec3 } from '../../contracts/assembly.ts';
import type { Protocol } from '../../contracts/device.ts';
/** 一个预置硬件型号的接口语义。 */
export interface HardwareModel {
    /** 模型库键。前端按它加载几何；`ComponentSpec.hardwareModel` 存的就是它。 */
    readonly key: string;
    readonly label: string;
    /** 端口定义。`occupiedBy` 由 AssemblyState 运行时填，这里只给静态语义。 */
    readonly ports: readonly Omit<Port, 'occupiedBy'>[];
    /** I2C 从机地址（若该型号是 I2C 设备）。用于地址冲突检测。 */
    readonly i2cAddress?: number;
    /** 自身功耗（瓦）。用于供电预算。 */
    readonly powerDrawW: number;
    /** 可作为电源，提供多少瓦预算。非电源为 0。 */
    readonly powerSupplyW: number;
}
/** 预置型号表。键 = `ComponentSpec.hardwareModel`。 */
export declare const HARDWARE_MODELS: Readonly<Record<string, HardwareModel>>;
/** 查型号。未知型号返回 undefined（调用方据此发 `unknown_hardware_model` 警告）。 */
export declare function findModel(key: string): HardwareModel | undefined;
/** 全部预置型号键。 */
export declare function modelKeys(): string[];
/** 未连接端口的默认落位（用户拖拽前的初值）。 */
export declare const DEFAULT_PLACE_POSITION: Vec3;
/** 判断某型号是否提供该协议端口。 */
export declare function modelSupportsProtocol(model: HardwareModel, protocol: Protocol): boolean;
/**
 * 由型号实例化出一个组件。
 *
 * @param id - 组件唯一 id（调用方提供，保证可复现）
 * @param modelKey - 型号键
 * @param position - 世界坐标（米）
 */
export declare function instantiate(id: string, modelKey: string, position: Vec3, rotation?: Vec3): ComponentSpec | undefined;
