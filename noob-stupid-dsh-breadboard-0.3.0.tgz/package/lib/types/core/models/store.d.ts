import { type ImportedModelRecord } from '../../contracts/protocol.ts';
export declare class ModelStoreError extends Error {
    readonly code: 'bad_key' | 'too_large' | 'bad_format' | 'io';
    constructor(code: ModelStoreError['code'], message: string);
}
export interface ModelStoreOptions {
    /** 存储根目录（用户数据目录下）。 */
    readonly root: string;
    readonly maxBytes?: number;
}
export declare class ModelStore {
    #private;
    constructor(options: ModelStoreOptions);
    get root(): string;
    /** 列出全部已导入模型。单个条目损坏时**跳过它而不是整个失败**。 */
    list(): Promise<ImportedModelRecord[]>;
    /** 读取某个模型的记录与字节。 */
    get(modelKey: string): Promise<{
        record: ImportedModelRecord;
        bytes: Buffer;
    } | undefined>;
    /**
     * 写入（覆盖）一个模型。
     *
     * ★ **原子**：先写临时文件 → `rename`。中断只会留下一个 `.tmp-*`，不会污染正式文件。
     */
    put(modelKey: string, bytes: Uint8Array, extra?: {
        size?: ImportedModelRecord['size'];
        label?: string;
    }): Promise<ImportedModelRecord>;
    /** 删除。返回是否真的删掉了东西。 */
    delete(modelKey: string): Promise<boolean>;
}
