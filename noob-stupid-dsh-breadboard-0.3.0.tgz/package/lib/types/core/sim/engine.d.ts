import type { VirtualClock } from '../vclock/virtual-clock.ts';
import type { AssemblyState } from '../state/assembly-state.ts';
import { HardwareEventBus } from '../events.ts';
import type { SimMode } from '../../contracts/assembly.ts';
import type { DeviceFault } from '../../contracts/device.ts';
/** 一个正在运行的项目进程。结构上等价于宿主 `SubprocessHandle` 的子集。 */
export interface SimProcessHandle {
    /**
     * 进程 id。**可选** —— 宿主的 `SubprocessHandle` **刻意不暴露它**
     * （服务契约原文："Target identity remains provider-private"）。
     *
     * ★ 不要为了让字段"填满"而编一个假 pid（`-1` / `0` / 自增计数）：
     *   日志里那行会**看着像诊断信息、实际是垃圾**，排查时把人带偏。
     *   这正是本项目失败族里的典型形态。拿不到就不打印。
     */
    readonly pid?: number;
    /** 进程结束时解析。**只在 spawn 级失败时 reject**。 */
    readonly done: Promise<{
        exitCode: number | null;
    }>;
    /** 终止（宿主实现应为**进程树级**终止）。 */
    terminate(): void;
}
export interface SimSpawnRequest {
    readonly argv: readonly string[];
    readonly cwd: string;
    readonly env: Readonly<Record<string, string>>;
    readonly onStdout: (text: string) => void;
    readonly onStderr: (text: string) => void;
}
/**
 * 进程能力注入点。宿主半用 `ctx.subprocess.spawn` 实现它。
 *
 * ★ 允许返回 Promise：宿主侧拉起进程前需要 `await subprocess.resolveExecutable()`
 *   （**执行世界的可执行文件解析**——宿主明确要求不要自己拼 PATH）。
 *   引擎本来就在 async 上下文里调用它，多一个 await 不改变任何时序约束：
 *   并发守卫 {@link SimEngine.run} 已在**第一个 await 之前**同步置位。
 */
export type SimSpawner = (request: SimSpawnRequest) => SimProcessHandle | Promise<SimProcessHandle>;
export interface SimEngineOptions {
    readonly clock: VirtualClock;
    readonly state: AssemblyState;
    readonly bus: HardwareEventBus;
    readonly spawn: SimSpawner;
    /** Python 解释器绝对路径。 */
    readonly pythonPath: string;
    /** `project-shim/` 目录绝对路径（注入 shim 用）。 */
    readonly shimRoot: string;
    /** 墙钟兜底超时（毫秒），防进程挂死。默认 60s。 */
    readonly maxWallMs?: number;
    /** 日志缓冲上限（行）。默认 2000。 */
    readonly maxLogLines?: number;
    /** 墙钟来源，可注入以便测试。 */
    readonly wallNow?: () => number;
}
export interface SimRunOptions {
    /** 项目根目录。 */
    readonly projectPath: string;
    /** 入口脚本（相对 projectPath）。默认 `main.py`。 */
    readonly entry?: string;
    /** **虚拟**时间长度（秒）。 */
    readonly duration: number;
    readonly mode: SimMode;
}
export interface SimRunResult {
    readonly ok: boolean;
    readonly exitCode: number | null;
    /** 实际推进的虚拟秒数。 */
    readonly virtualElapsed: number;
    readonly wallElapsedMs: number;
    /** 项目进程的输出（含 shim 上报的日志）。 */
    readonly log: readonly string[];
    /** 结束原因：`exited` / `budget` / `timeout` / `error`。 */
    readonly reason: 'exited' | 'budget' | 'timeout' | 'error';
    /** 失败时的说明。 */
    readonly message?: string;
}
export declare class SimEngine {
    #private;
    constructor(options: SimEngineOptions);
    /** 是否正在跑。 */
    get running(): boolean;
    /** 最近一次（或正在进行的）仿真的日志。 */
    get log(): readonly string[];
    /**
     * 运行一次仿真。
     *
     * ★ **并发守卫必须在第一个 `await` 之前同步置位。**
     *   实测踩过：守卫原来写在 `server.listen()` / `spawn()` **之后**，
     *   而这两步之间隔着 await —— 第二次调用会在第一次置位之前就穿过去，
     *   守卫形同虚设。**「看起来对、因为 await 时序而不生效」属于本项目的失败族。**
     *
     * ★ 为什么必须拒绝而不是排队：两个项目进程共享同一份虚拟硬件会互相篡改状态，
     *   虚拟时钟还会被双重推进。排队更糟 —— 调用方会以为"提交了就开始了"。
     */
    run(options: SimRunOptions): Promise<SimRunResult>;
    /**
     * 运行期间注入故障（§8 流程 C）。
     *
     * `target` 形如 `bme280:0x76` 或直接给设备/组件 id。
     */
    injectFault(target: string, fault: DeviceFault): boolean;
    /** 关停（插件卸载时调用）。 */
    dispose(): Promise<void>;
}
