import type { VirtualClock } from '../vclock/virtual-clock.ts';
import type { VirtualDevice } from '../../contracts/device.ts';
export interface BridgeServerOptions {
    /** 虚拟时钟 —— `clock_advance` 会真的推进它并按时间片 tick 所有设备。 */
    readonly clock: VirtualClock;
    /** 设备来源。默认取 `clock.listDevices()`（设备登记在时钟上，天然同一份）。 */
    readonly devices?: () => readonly VirtualDevice[];
    /** 监听端口。默认 0（OS 分配，避免固定端口冲突）。 */
    readonly port?: number;
    /** 监听地址。默认 127.0.0.1 —— **绝不要**改成 0.0.0.0。 */
    readonly host?: string;
    /** 指定 token；省略则随机生成。 */
    readonly token?: string;
    /** 项目进程的日志（shim 主动上报，保留与硬件访问的因果顺序）。 */
    readonly onLog?: (stream: 'stdout' | 'stderr', text: string) => void;
    /** 插件版本，握手里回给 shim 便于对照排查。 */
    readonly hostVersion?: string;
    /**
     * 虚拟时间预算（微秒）。超出后 `clock_advance` 会被**截断**且不再推进。
     *
     * ★ 为什么预算必须在这里执行，而不是引擎里计时：
     *   仿真的 `duration` 是**虚拟秒**，而虚拟时钟**只由 `clock_advance` 推进**。
     *   墙钟计时会在 accelerated 模式下完全失效 —— 5 秒虚拟时间可能只花 100ms 真实时间
     *   （实测：含 `sleep(1)×5` 的脚本真实耗时约 100ms）。**只有推进时钟的地方才知道该停。**
     */
    readonly virtualBudgetMicros?: number;
    /** 预算耗尽时回调（引擎据此终止项目进程）。 */
    readonly onBudgetExhausted?: () => void;
    /**
     * 每次推进之后回调（可 await）。
     * realtime 模式的限速落点 —— 引擎在这里按虚拟/真实时间比率补等待。
     */
    readonly onAdvance?: (result: {
        nowMicros: number;
        advancedMicros: number;
    }) => void | Promise<void>;
}
/** 监听成功后回填给项目进程的连接参数。 */
export interface BridgeAddress {
    readonly host: string;
    readonly port: number;
    readonly token: string;
    /** 直接可用的子进程环境变量（喂给 `subprocess.spawn` 的 `env`）。 */
    readonly env: Readonly<Record<string, string>>;
}
export declare class BridgeServer {
    #private;
    constructor(options: BridgeServerOptions);
    /** 虚拟时间预算是否已耗尽。 */
    get budgetExhausted(): boolean;
    get address(): BridgeAddress | undefined;
    get connectionCount(): number;
    /** 已通过握手的连接数（诊断用：能区分「连上了但没鉴权」与「压根没连」）。 */
    get handshakenCount(): number;
    /** 开始监听。返回回填给项目进程的连接参数。 */
    listen(): Promise<BridgeAddress>;
    /** 关闭监听并断开所有连接（**不**推进虚拟时钟）。 */
    close(): Promise<void>;
}
