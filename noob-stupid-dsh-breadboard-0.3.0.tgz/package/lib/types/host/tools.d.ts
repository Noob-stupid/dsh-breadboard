/**
 * 工具注册 —— 把内核能力暴露给 DS（设计文档 §5.4 / §10 薄适配层）
 * @module dsh-breadboard/host/tools
 *
 * ★ 与 `routes.ts` 同属适配层：**结构等价**宿主类型，不 import 宿主包。
 *   §10.3 要求内核零依赖宿主 API；宿主接口若改名，改动收敛在本文件。
 *
 * ★★ DSH 的 JSON Schema 方言 —— **两个位置不一样，这里是踩过的坑**：
 *
 *   DSH 内部有**两套** schema 形态（`packages/core/tools/src/schema.ts`）：
 *
 *   | 位置 | 形态 | `required` 怎么写 |
 *   |---|---|---|
 *   | `parameters`（**源方言**） | `ParameterSchemaSpec` | **每个属性里 `required: true`** |
 *   | `output.schema`（**已编译**） | `ValueSchemaSpec` / `JsonSchemaNode` | **对象级 `required: ['a','b']` 数组** |
 *
 *   `parameters` 的"属性内 `required: true`"是**给人写的源方言**，
 *   由 `defineTool()` 编译成标准 JSON Schema（见 `schema.ts` 的 `property-map-tail`：
 *   它把逐属性的 `required: true` 收集成对象级 `required` 数组）。
 *
 *   ⚠️ **我们不用 `defineTool`** —— §10.3 要求内核零依赖宿主 API，本文件刻意只做
 *      **结构等价类型**。⇒ **没有编译这一步，两边都必须自己写成标准 JSON Schema**：
 *      · `output.schema` 会过 `assertSupportedJsonSchema()`，写成源方言会**注册失败**
 *        （实测报错：`schema.properties.ok.required is not supported on type "boolean"`）
 *      · `parameters` **不做校验**、原样交给模型 ⇒ 写成源方言**不会报错**，
 *        但模型看到的是一个非法/无效的 schema，`required` 形同虚设 ——
 *        **静默失效，比注册失败更坏**
 *
 *   ★ 另：`output.schema` 还会在**每次调用后校验返回值**
 *     （`validateJsonSchemaValue(tool.output.schema, value)`），所以
 *     声明必须与**实际返回的形状**逐字段一致 —— 少一个字段、多一个字段都会失败。
 *     `tests/hardware-tools.test.ts` 用"声明键集合 == 实际返回键集合"把它钉住。
 *
 *   其他约定：对象级用 `additionalProperties: false`；`output` 必填。
 */
import type { SimEngine } from '../core/sim/engine.ts';
import type { AssemblyState } from '../core/state/assembly-state.ts';
/** 内容块 —— 结构等价于宿主的 `ContentBlock`（只用到 text）。 */
export interface ContentBlockLike {
    readonly type: 'text';
    readonly text: string;
}
interface ToolOutput {
    readonly schema: Record<string, unknown>;
    readonly render: (args: unknown, value: unknown) => ContentBlockLike[];
}
/** 结构等价于宿主 `ToolDefinition`。 */
export interface HardwareToolDefinition {
    readonly name: string;
    readonly description: string;
    readonly parameters: Record<string, unknown>;
    readonly output: ToolOutput;
    readonly execute: (args: unknown, exec: {
        signal?: AbortSignal;
    }) => Promise<unknown>;
}
/** 结构等价于宿主 `tools` 服务。 */
export interface ToolRegistryLike {
    register(definition: HardwareToolDefinition): () => void;
}
export declare const text: (value: string) => ContentBlockLike[];
/** 把值安全地转成对象（模型可能传 null / 非对象）。 */
export declare function asRecord(value: unknown): Record<string, unknown>;
export interface HardwareToolDeps {
    readonly engine: SimEngine;
    readonly state: AssemblyState;
    /** 本机 Python 解释器路径（探测结果），用于工具描述里如实说明。 */
    readonly pythonPath: string;
}
export declare function createHardwareTools(deps: HardwareToolDeps): HardwareToolDefinition[];
export {};
