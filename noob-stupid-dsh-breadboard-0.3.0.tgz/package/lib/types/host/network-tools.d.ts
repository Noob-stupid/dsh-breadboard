/**
 * 联网设备工具 —— 把第二类虚拟硬件暴露给 DS（设计文档 §5.4 / §10 薄适配层）
 * @module dsh-breadboard/host/network-tools
 *
 * ★ 与 `tools.ts` 同属适配层，**同样的 schema 纪律**（详见 `tools.ts` 文件头）：
 *   · `parameters` 与 `output.schema` **都要写成已编译的标准 JSON Schema**
 *     （对象级 `required: [...]` 数组，**不是**逐属性 `required: true`）
 *     因为我们不用 `defineTool`，没有编译那一步
 *   · `output.schema` 会在**每次调用后校验返回值** ⇒ 声明必须与实际返回逐字段一致
 *
 * ★ 与仿真工具分开成两个文件：它们管的是**两类不同的虚拟硬件**，
 *   混在一起会让人以为"联网设备也是挂在虚拟时钟上的"。
 */
import type { NetworkRegistry } from '../core/sim/network-registry.ts';
import type { AssemblyState } from '../core/state/assembly-state.ts';
import type { HardwareToolDefinition } from './tools.ts';
/** 联网设备型号（`library.ts` 里那个无端口型号）。 */
export declare const NETWORK_DEVICE_MODEL = "esp32-seat-sensor";
export interface NetworkToolDeps {
    readonly registry: NetworkRegistry;
    readonly state: AssemblyState;
    /** 已知协议 id → 说明，供工具描述与校验使用。 */
    readonly protocols: Readonly<Record<string, string>>;
}
export declare function createNetworkTools(deps: NetworkToolDeps): HardwareToolDefinition[];
