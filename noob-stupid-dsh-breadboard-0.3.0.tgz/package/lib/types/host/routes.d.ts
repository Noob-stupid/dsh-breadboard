/**
 * 宿主半路由 —— 前端 ↔ 宿主 的桥（设计文档 §10 的「薄适配层」）
 * @module dsh-breadboard/host/routes
 *
 * ★ 为什么是 HTTP/WS 而不是 `host.call`：
 *   `host.call` 只存在于「动态 Cordis 插件」的 runner 路径（cordis-client-runner），
 *   **bundle 插件的前端半没有这个符号**（已对整个 checkout 核对过）。
 *   本插件是 bundle 插件，所以一律走 `ctx.webServer.register` + 前端 fetch。
 *
 * ★ 为什么这里自定义 `HttpRoute` / `UpgradeRoute` 结构而不 import 宿主类型：
 *   §10.3 要求「内核零依赖宿主 API，一律走 hostAdapter.*」。本文件就是那一层。
 *   结构上与宿主 `WebRoute` / `WebUpgradeRoute` 等价（`kind`/`path`/`handler`），
 *   但宿主接口改名或迁移时，改动**收敛在本文件**，内核不受影响。
 */
import type { IncomingMessage, ServerResponse } from 'node:http';
import type { Duplex } from 'node:stream';
import type { ProjectStatus } from '../contracts/projects.ts';
import type { ProjectBody, ProjectScanOutcome } from '../core/projects/store.ts';
import type { AssemblyState } from '../core/state/assembly-state.ts';
import type { HardwareEventBus } from '../core/events.ts';
import type { ModelStore } from '../core/models/store.ts';
import type { StepPartsClient } from '../core/models/step-parts.ts';
import type { ChatSendRequest, ChatSendResult, HostCapabilities, ModelSearchSource } from '../contracts/protocol.ts';
/** 结构等价于宿主 `WebRoute`。 */
export interface HttpRoute {
    readonly kind: 'exact' | 'prefix';
    readonly path: string;
    readonly handler: (req: IncomingMessage, res: ServerResponse) => void | Promise<void>;
}
/** 结构等价于宿主 `WebUpgradeRoute`。 */
export interface UpgradeRoute {
    readonly path: string;
    readonly handler: (req: IncomingMessage, socket: Duplex, head: Buffer) => void | Promise<void>;
}
/**
 * 搜索能力注入点。宿主半用 `ctx.web.search` 实现它。
 *
 * ★ 为什么是注入而不是直接调宿主服务：§10.3「内核零依赖宿主 API」。
 *   宿主搜索接口若改名，改动收敛在 `index.ts` 一处。
 *
 * ★ 它只负责**通用搜索那一半**（外链）；结构化候选由 {@link StepPartsClient} 提供。
 *   两半在搜索路由里合成完整的 `ModelSearchResult`。
 */
export type ModelSearcher = (query: string) => Promise<{
    readonly sources: readonly ModelSearchSource[];
    readonly content?: string;
    readonly unavailable?: string;
}>;
export interface RouteDeps {
    readonly state: AssemblyState;
    readonly bus: HardwareEventBus;
    /** 能力探测结果（§10.1）。用函数以便随环境变化。 */
    readonly capabilities: () => HostCapabilities;
    /** 用户导入模型的存储。省略则模型路由不注册。 */
    readonly models?: ModelStore;
    /** 搜索能力。省略则搜索路由不注册（界面应降级为"只给外链"）。 */
    readonly search?: ModelSearcher;
    /**
     * step.parts 客户端 —— **结构化候选 + 一键导入**。
     * 省略则搜索只返回外链（用户自己下载后手动导入）。
     */
    readonly stepParts?: StepPartsClient;
    /**
     * 面板浮层输入框的投递口（见 `host/chat.ts`）。
     * 省略则聊天路由不注册（界面应隐藏输入框，而不是给一个发不出去的框）。
     */
    readonly chat?: (request: ChatSendRequest) => ChatSendResult;
    /** handler 抛错时的上报口（默认静默）。 */
    readonly onError?: (error: unknown) => void;
    /**
     * **项目**：状态查询 + 导入样例 + 删除（省略则项目路由不注册）。
     *
     * ★ 传**一组函数**而不是注册表本身（与 `capabilities` 同一手法）：
     *   路由层不必知道 `ProjectStore` 的存在，也不必知道"连通"怎么算 ——
     *   它只负责把数据发给前端、把用户的操作转下去。判据一变，这里一行都不用改。
     *
     * ★ 为什么"导入样例"和"删除"走 HTTP 而**不是** ClientAction：
     *   action 那条路的语义是"**改装配**"（放器件、连线、钉住），进的是 SSOT；
     *   而项目的增删是"**改用户目录里的文件**"，与装配状态无关。
     *   塞进 action 会让 `AssemblyState` 平白多出一个它管不着的东西。
     */
    readonly projects?: {
        readonly list: () => Promise<readonly ProjectStatus[]>;
        /** 把随包样例装进用户目录。**只有用户显式导入时才调**（默认列表是空的）。 */
        readonly importSample: (projectId: string) => Promise<boolean>;
        /**
         * **存一份用户给的项目定义**（从**文件**导入 / agent 建的）。
         *
         * ★ 与 `importSample` 分开而不是合成一个：那个的输入是**一个 id**，
         *   这个的输入是**一整份图纸**。合成一个就得在实现里判"到底是哪种"，
         *   而判错的表现是"**导入成功但项目是空的**" —— 最难查的一类。
         *
         * 返回**人话原因**（`undefined` = 成功）：文件是用户给的，可能缺字段、
         * id 非法、根本不是 JSON —— 每一种都要说清是哪种。
         */
        readonly save: (profile: unknown) => Promise<string | undefined>;
        /**
         * **把当前场景存回这个项目**（"保存现有建模"）。
         *
         * ★ 与 `save` 分开：那个存的是**用户给的一份图纸**（文件里的），
         *   这个存的是**眼前这套装配**（用户刚摆的、刚连的）。
         *   来源完全不同，合成一个就得在实现里判"到底用哪个"，
         *   而判错的表现是「**保存成功，但存的是旧的那份**」—— 用户以为白干了。
         */
        readonly saveScene: (projectId: string) => Promise<string | undefined>;
        readonly remove: (projectId: string) => Promise<boolean>;
        /**
         * **项目本体**（用户导入的真实项目文件夹）。
         *
         * ★★ 用户原话：
         *   > 上传项目本体，你**上传后那得显示项目啊**，
         *   > 那个扫描可以**后续扫描按钮**，**先上传项目到那里**
         *
         *   ⇒ 两步分开：**先上传（进列表）**，**再扫描（按钮）**。
         *     而不是"一上传就扫、扫完就没影了"。
         */
        readonly bodies: {
            readonly list: () => Promise<readonly ProjectBody[]>;
            /** 存一份本体快照（用户选文件夹上传时）。 */
            readonly save: (body: ProjectBody) => Promise<void>;
            readonly remove: (bodyId: string) => Promise<boolean>;
            /** **扫描一份已存的本体** —— 只有用户点"扫描"时才调。 */
            readonly scan: (bodyId: string) => Promise<{
                readonly ok: true;
                readonly report: ProjectScanOutcome;
            } | {
                readonly ok: false;
                readonly reason: string;
            }>;
        };
    };
}
/**
 * **扫描项目本体，得出它"看起来需要哪些硬件"**。
 *
 * ★★ 用户的工作流第②步：
 *   > 导入项目后可以**扫描看看项目需求硬件建模**，根据这个干建模，
 *   > 如果网上有建模自己导入不了就**写个清单发给用户**，没有就**自己建模没有的部分**
 *
 * ⚠️⚠️ **它只出报告，不生成装配。** 装配该怎么接是**看代码后决定的** ——
 *   猜出来的装配会有"看起来对但接错了"的风险，而它**不会报错**
 *   （本项目失败族里最贵的那一类）。
 *
 * ★ 匹配靠**词表**而不是智能推断：词表是**可审计的** ——
 *   报告里会带上"在哪几个文件里看到的"，用户能自己判断对不对。
 *   纯推断给不出证据，而**没有证据的结论在这里等于没有结论**。
 */
export declare function scanProjectNeeds(files: readonly {
    path?: unknown;
    text?: unknown;
}[], models: ModelStore | undefined): Promise<{
    readonly fileCount: number;
    readonly matched: readonly {
        readonly modelKey: string;
        readonly label: string;
        readonly hasGeometry: boolean;
        readonly evidence: readonly string[];
    }[];
    readonly missingGeometry: readonly string[];
}>;
export declare function createHttpRoutes(deps: RouteDeps): HttpRoute[];
/**
 * WebSocket 升级路由。
 *
 * ★ 握手必须自己来：宿主的 `registerUpgrade` 只给原始 socket 与 `head`，
 *   协议协商（Sec-WebSocket-Accept 等）由本路由负责。这也是引入 `ws` 的原因 ——
 *   手写帧解析（掩码/分片/ping-pong/close）不值得，且容易出隐蔽 bug。
 */
export declare function createUpgradeRoutes(deps: RouteDeps): {
    routes: UpgradeRoute[];
    dispose: () => void;
};
/**
 * 一次性组装全部路由 + 卸载钩子。
 * ★ `dispose` 必须被真的调用（挂到 ctx.effect 上），否则插件热重载会残留
 *   事件订阅与 WebSocket 连接 —— 表现为「卸载了还在推消息」。
 */
export declare function createRouteBundle(deps: RouteDeps): {
    http: HttpRoute[];
    upgrade: UpgradeRoute[];
    dispose: () => void;
};
