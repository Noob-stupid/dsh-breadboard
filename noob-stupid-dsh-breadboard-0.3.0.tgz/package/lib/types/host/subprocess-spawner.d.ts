/**
 * 宿主 `subprocess` → {@link SimSpawner} 适配器（设计文档 §10 薄适配层）
 * @module dsh-breadboard/host/subprocess-spawner
 *
 * ★ 与 `routes.ts` / `tools.ts` 同属适配层：**结构等价**宿主类型，不 import 宿主包。
 *   §10.3 要求内核零依赖宿主 API；宿主接口若改名，改动收敛在本文件。
 *
 * ── 这个适配器要解决的三个**真实差异**（每一个做错了都很难查） ──
 *
 * ① **宿主刻意不暴露进程身份。**
 *    服务契约原文："Target identity remains provider-private" —— `SubprocessHandle` 上
 *    **没有 `pid`**（只有 `SubprocessTerminalHandle` 有）。所以这里**不编造** pid，
 *    拿不到就留空，由引擎决定不打印。编一个 `-1` 出来只会让日志**看着像诊断信息、实际是垃圾**。
 *
 * ② **流 vs 回调。**
 *    宿主给的是 `Readable` 流，引擎要的是 `onStdout/onStderr(text)` 回调。
 *    而且**必须按行切**：`bridge_client.py` 的 `log()` 文档写明"把**一行**日志上报给宿主"，
 *    所以引擎 `log` 数组的语义是**行**。若把原始 chunk 直接塞进去，
 *    `hw_get_sim_log` 的 `totalLines` 会变成"chunk 数"——数字看着正常，含义是错的。
 *    ⇒ 用 {@link LineSplitter} 缓冲半行，流结束时 flush 尾行。
 *
 * ③ **`done` 的语义比"进程退出"要宽。**
 *    宿主 `done` 只保证"退出事实"，**不保证 stdout 已经排空**。
 *    直接透传会**丢掉最后几行输出**（恰恰是最关键的报错）。
 *    ⇒ `done` 等**进程退出 + 两条流都结束**，两者齐了才解析。
 *
 * ★ `resolveExecutable` 存在的意义：宿主明确要求可执行文件在**它自己的执行世界**里解析
 *   （"Absolute paths are verified; bare names use the provider's scrubbed PATH"）。
 *   自己去拼 PATH 在远程/容器执行世界里必然错。所以这里先解析、再 spawn。
 */
import type { Readable } from 'node:stream';
import type { SimSpawner } from '../core/sim/engine.ts';
interface SubprocessOutcomeLike {
    readonly exitCode: number | null;
}
interface SubprocessHandleLike {
    readonly stdout?: Readable | undefined;
    readonly stderr?: Readable | undefined;
    readonly done: Promise<SubprocessOutcomeLike>;
    terminate(): void;
}
interface SubprocessSpawnSpecLike {
    readonly argv: readonly string[];
    readonly cwd: string;
    readonly stdio: {
        readonly stdin: 'ignore' | 'pipe' | {
            readonly data: string;
        };
        readonly stdout: unknown;
        readonly stderr: unknown;
        readonly control?: 'pipe';
    };
    readonly graceMs: number;
    readonly signal?: AbortSignal | undefined;
    readonly env?: Record<string, string | undefined> | undefined;
}
/** 结构等价于宿主 `subprocess` 服务（只用到这两个方法）。 */
export interface SubprocessLike {
    /**
     * 在宿主的执行世界里解析可执行文件。
     *
     * **可选**：老版本宿主可能没有它，那时退化为"原样使用 argv[0]"。
     * 不做硬依赖 —— 缺了它仿真仍应能跑（只是少了路径校验）。
     */
    resolveExecutable?(command: string, env?: Readonly<Record<string, string>>, signal?: AbortSignal): Promise<string>;
    spawn(spec: SubprocessSpawnSpecLike): SubprocessHandleLike;
}
export interface SubprocessSpawnerOptions {
    /**
     * 终止宽限期（毫秒）—— 交给宿主的进程树级终止流程。
     * 默认 3000：足够 Python 跑完 `finally` 里的清理，又不至于让一次卡死的仿真拖太久。
     */
    readonly graceMs?: number;
}
/**
 * 把任意切分的文本块还原成**行**。
 *
 * ★ 为什么不能直接 `chunk.split('\n')`：chunk 边界**与行边界无关**，
 *   一次 read 可能切在行中间。不缓冲就会把一行劈成两条日志（或多行并成一条）。
 */
export declare class LineSplitter {
    #private;
    constructor(emit: (line: string) => void);
    push(chunk: string): void;
    /** 流结束时把没有换行符的尾行吐出来（否则最后一行永远丢失）。 */
    flush(): void;
}
export interface PythonProbeResult {
    /** 解析后的可执行文件绝对路径。 */
    readonly path: string;
    /** `Python 3.14.2` 里的版本号部分。 */
    readonly version: string;
}
/** 默认探测顺序。 */
export declare const DEFAULT_PYTHON_CANDIDATES: readonly string[];
/**
 * 探测一个可用的 Python 解释器。
 *
 * ★★ **为什么"解析得到"还不够，必须真跑一次 `--version`**：
 *   Windows 上 `python3` 常常解析到
 *   `%LOCALAPPDATA%\Microsoft\WindowsApps\python3.exe` —— 那是个**应用商店占位存根**，
 *   不是解释器。`resolveExecutable` 会**成功地**返回它（它确实存在于 PATH 上），
 *   但一跑就打印"Python was not found…"并以非零码退出。
 *
 *   实测本机：`python` → `E:\python314\python.exe`（真的 3.14.2）；
 *            `python3` → WindowsApps 存根（假的）。
 *   ⇒ 若只按"解析成功"取第一个候选，会**优先选中那个假的**，
 *     之后每一次仿真都以一个看不懂的退出码失败。所以探测必须**验证行为**。
 *
 * ★ `preferred` 非空时**只用它，不回落**：用户显式配置了路径，
 *   悄悄换一个解释器会让"我配的那个为什么不生效"变成一个查不出的问题。
 *   失败就如实返回 undefined，由调用方给出可操作的提示。
 *
 * @returns 找到可用解释器时返回它；一个都不行则 `undefined`（**不抛**）。
 */
export declare function probePythonInterpreter(subprocess: SubprocessLike, options?: {
    readonly preferred?: string;
    readonly candidates?: readonly string[];
    readonly timeoutMs?: number;
}): Promise<PythonProbeResult | undefined>;
/**
 * 把宿主的 `subprocess` 服务包成引擎要的 {@link SimSpawner}。
 *
 * 返回的函数**可能抛**（argv 为空、可执行文件解析失败）—— 引擎在 `try` 里调用它，
 * 会把失败如实报成 `reason='error'`，不会静默。
 */
export declare function createSubprocessSpawner(subprocess: SubprocessLike, options?: SubprocessSpawnerOptions): SimSpawner;
export {};
