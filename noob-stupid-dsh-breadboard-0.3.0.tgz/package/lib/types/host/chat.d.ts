/**
 * 面板浮层输入框 → 会话（设计文档 §10 薄适配层）
 * @module dsh-breadboard/host/chat
 *
 * ══════════════════════════════════════════════════════════════════════════
 * ★★ 这条通道很容易找错 —— 我第一遍就找错了，记在这里免得再犯
 * ══════════════════════════════════════════════════════════════════════════
 *
 * | 看起来像"发消息"的 | 实际是 |
 * |---|---|
 * | `commands.execute(agent, line, …)` | 文档原文 **"execute a known command *without sending it to the model*"** —— 斜杠命令，**不产生对话轮次** |
 * | `Session.append('user/message', …)` | 只往**日志**写事件，**不驱动 agent loop** |
 * | **`Agent.followup(input)`** | ✅ `send(input,'next-turn',true)` —— **就是"用户发消息、开新一轮"** |
 *
 * 前两个做出来的东西是「**看着像发了消息、其实模型没收到**」——
 * 正是本项目失败族的形态。所以这里只走第三条。
 *
 * ══════════════════════════════════════════════════════════════════════════
 * ★ 消息是**结构等价构造**的，不 import `@deepseek-ai/dsh-llm`
 * ══════════════════════════════════════════════════════════════════════════
 *
 * `createUserMessage({content, source})` 的运行时实现只是
 * `freezeMessage({ ...input, id: randomUUID(), role: 'user' })` ——
 * 所以结构等价构造是**逐字段相同**的。
 *
 * 为什么不直接 import：`dsh-llm` 是**核心包**，运行时不在 profile 的 `node_modules` 里
 * （只有 checkout 的 `lib/types`，没有构建产物），值导入会 ERR_MODULE_NOT_FOUND。
 * §10.3 也要求内核零依赖宿主 API。
 *
 * ⚠️ **代价**：形状若漂移，我们不会在编译期知道。
 *    ⇒ 所以这里对**方法是否存在**做显式检查（`followup` / `send`），
 *      缺失就**明确拒绝**，而不是静默调一个不存在的函数。
 *      形状本身的最终判据是端到端：消息真的出现在会话里。
 */
import type { ChatSendRequest, ChatSendResult } from '../contracts/protocol.ts';
/** 结构等价于宿主 `Agent`（只用到这几项）。 */
export interface AgentLike {
    readonly id: string;
    /** `send(input, 'next-turn', true)` —— 用户发消息、开新一轮。 */
    followup?(input: unknown): void;
    send?(message: unknown, target: 'next-turn' | 'next-step', wakeup: boolean): void;
}
/** 结构等价于宿主 `agents` 服务。 */
export interface AgentsLike {
    list(): readonly AgentLike[];
    get(id: string): AgentLike | undefined;
}
/**
 * 造一个"发消息给会话"的函数。
 *
 * @returns 成功时 `{ok:true, sessionId, messageId}`；失败时 `{ok:false, reason}`（**不抛**，
 *   因为这是前端调用的路径，抛出去只会变成一个没有 body 的 500）。
 */
export declare function createChatSender(agents: AgentsLike | undefined, newId?: () => string): (request: ChatSendRequest) => ChatSendResult;
