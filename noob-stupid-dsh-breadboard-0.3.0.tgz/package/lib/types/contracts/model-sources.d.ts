/** 这个来源主要能提供什么。 */
export type ModelSourceProvides = 'geometry' | 'symbol' | 'datasheet' | 'search';
export interface ModelSource {
    readonly id: string;
    readonly label: string;
    /**
     * 打开的 URL 模板。`{q}` 会被替换为 **URL 编码后**的查询词。
     * 见 {@link sourceUrl}。
     */
    readonly urlTemplate: string;
    readonly provides: ModelSourceProvides;
    /** 给用户的一句提示（许可、格式、注意事项）。 */
    readonly note?: string;
}
/**
 * 通用网络搜索 —— **兜底，且永远可用**。
 *
 * ★ 为什么必须有它：站点深链的 URL 规则我们**无法验证**（见文件头），
 *   而通用搜索不依赖任何站点的规则。**用户不会因为某个模板失效而卡住。**
 */
export declare const WEB_SEARCH_SOURCE: ModelSource;
/** 预置来源清单。 */
export declare const MODEL_SOURCES: readonly ModelSource[];
/**
 * 把查询词代入模板。
 *
 * @param source - 来源
 * @param query - 原始查询词（**不要**预先编码，本函数会编码）
 */
export declare function sourceUrl(source: ModelSource, query: string): string;
/**
 * 为某个型号生成建议的搜索词。
 *
 * ★ 用 `HARDWARE_MODELS[key].label`（如「BME280 温湿度气压传感器」）而不是裸 key ——
 *   站点上认的是人话，不是我们的内部键。
 */
export declare function searchQueryFor(modelKey: string, extra?: string): string;
