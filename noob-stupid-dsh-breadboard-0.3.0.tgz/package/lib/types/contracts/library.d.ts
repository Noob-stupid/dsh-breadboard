/**
 * 硬件模型库 `schema/` —— 接口语义 + **几何尺寸**（共享契约）
 * @module dsh-breadboard/contracts/library
 *
 * ★ 设计文档 §6.6：`ModelLib` 分 `geometry/`（几何模型）与 `schema/`（接口语义，核心壁垒）。
 *   本文件是 `schema/` 的**唯一真相**，且刻意放在 `contracts/` 而非 `core/`：
 *   宿主半、前端场景半**都要读它**，所以它是共享契约而不是某一侧的私有实现。
 *
 * ── ★★ 原点约定（必须写死，否则每个型号都要人工对齐）★★ ──
 *
 *   **组件局部坐标原点 = 其几何包围盒的中心（bbox center）**，x / y / z 三轴统一。
 *   `Port.position` 与 `ComponentSpec.position` 都遵循此约定。
 *
 *   为什么选「居中」而不是「角原点」（CAD/PCB 常见的 min 角）：
 *
 *   ① **旋转枢轴**（决定性理由）：Three.js 的 `mesh.rotation` 绕**局部原点**旋转。
 *      原点在角上 ⇒ 旋转时组件绕角甩出去，端口跟着飞出，交互上手感是错的。
 *   ② Three.js 的 `BoxGeometry` 等图元**默认就是居中**的，无需 `geometry.translate()`。
 *   ③ 「外部 STEP/glTF 模型多按角原点导出」不成立：各家导出原点本来就五花八门，
 *      导入任何外部模型都**必须**按包围盒做一次原点归一化。
 *
 *   ⚠️ **y 轴的后果**：`position.y` 是组件**中心**高度，让组件「平放在地面」要写
 *      `position.y = size.y / 2`。用 {@link restingY} 取，别手算。
 *
 * ── ★ 端口位置：声明式布局规则（`portLayout`）──
 *
 *   端口位置**不再逐个手打坐标**，而是用一条规则声明：
 *
 *   ```ts
 *   portLayout: { edge: '+z', pitch: 0.012, count: 6, inset: 0.005 }
 *   ```
 *
 *   理由：手打坐标**已经出过一次错**（三个型号混用两套原点约定，树莓派 6 个端口
 *   4 个落在几何体外）。声明式规则让**等距由规则推出**而非人肉保证，并且让自检
 *   从「逐点在盒内」升级为**结构性校验**（见 {@link validateLayout}）。
 *
 *   ⚠️ **声明顺序 ≠ 几何顺序**。实测踩过：bme280 的端口按 `I2C / VCC / GND` 声明，
 *      但几何上依次是 `z = 0 / +pitch / −pitch`（中间、右、左）。所以规则提供
 *      `order`（**按 portId 列出几何顺序**）来显式表达，而不是靠索引数字去数。
 */
import type { Port, Vec3 } from './assembly.ts';
import type { Protocol } from './device.ts';
/** 端口排布所依附的边。'+z' 表示「贴着 +z 那条边、沿 x 方向排」。 */
export type LayoutEdge = '+x' | '-x' | '+z' | '-z';
/**
 * 声明式端口布局规则。
 *
 * 语义：端口沿 `edge` 平行的方向**等距**排布，整体**在该轴上居中**，
 * 垂直方向距该边 `inset` 米，高度默认贴顶面。
 *
 * ★★ **双排**（`rows: 2`）：排针（如树莓派 40pin）是 **2×N** 的，
 *   单排模型表达不了它。开启后按 **`order` 的下标**分排：
 *
 * ```text
 * 下标 0 → 第 0 排，第 0 列      下标 1 → 第 1 排，第 0 列
 * 下标 2 → 第 0 排，第 1 列      下标 3 → 第 1 排，第 1 列
 * …即 row = index % rows，column = floor(index / rows)
 * ```
 *
 * ⇒ **`order` 按引脚编号 1,2,3,4… 列出时，正好得到真实的物理排布**
 *   （奇数脚一排、偶数脚另一排，如树莓派的 1/3/5… 与 2/4/6…）。
 *
 * ⚠️ 两排**对称跨在 `inset` 线上**（`inset ± rowPitch/2`），
 *   所以 `inset` 给的是**两排的中线**到边的距离，不是某一排的。
 */
export interface PortLayoutRule {
    /** 依附的边。'+z' ⇒ 行沿 x 轴；'+x' ⇒ 行沿 z 轴。 */
    readonly edge: LayoutEdge;
    /** 相邻端口间距（米）。**同排内**的列间距。 */
    readonly pitch: number;
    /** 端口数量。必须与 `ports.length` 一致。 */
    readonly count: number;
    /** 距所依附那条边的内缩（米）。双排时是**两排中线**的距离。 */
    readonly inset: number;
    /** 端口高度（米，组件局部坐标）。省略则取顶面下 {@link TOP_FACE_INSET}。 */
    readonly height?: number;
    /**
     * **排数**。省略 = 1（单排）。排针填 **2**。
     * ★ 取 2 是实测需要：树莓派 40pin / ESP32 排针都是 2×N。
     */
    readonly rows?: number;
    /**
     * **排间距**（米）。省略则取 {@link PITCH_254}（2.54mm，标准排针）。
     * ⚠️ 只在 `rows ≥ 2` 时有意义。
     */
    readonly rowPitch?: number;
    /**
     * **沿边方向的整体偏移**（米）。省略 = 0（在该轴上居中）。
     *
     * ★ 为什么需要它：**排针在板上本来就不居中**。
     *   实测树莓派 40pin 的中心在 **x ≈ −4mm**，而 `edge:'-z'` 的默认居中会把
     *   20 列铺在 ±24.13mm ⇒ 一端探出排针之外。
     *   （**"居中"是个方便，不是事实** —— 真实器件上很少有东西正好在几何中心。）
     */
    readonly offset?: number;
    /**
     * **几何顺序**：按 portId 列出端口的排列次序（从负方向到正方向）。
     * 省略则使用 `ports` 的声明顺序。
     * ★ 双排时它是**按「第0排第0列、第1排第0列、第0排第1列…」**交错消费的 —— 见接口说明。
     */
    readonly order?: readonly string[];
}
/** 端口默认落位：顶面下 0.1mm（避免与顶面共面导致 z-fighting）。 */
export declare const TOP_FACE_INSET = 0.0001;
/** 源模型的一条轴（带符号）。用于 {@link ModelOrientation}。 */
export type SourceAxis = '+x' | '-x' | '+y' | '-y' | '+z' | '-z';
/**
 * **朝向覆盖** —— 人工指定"源模型里哪条轴是厚度、哪条是长度"。
 *
 * ══════════════════════════════════════════════════════════════════════════
 * ★ 符号的读法（**读错会静默翻转模型，而包围盒看不出来**）
 * ══════════════════════════════════════════════════════════════════════════
 *
 * `up: '-z'` 读作「**源模型的 −z 方向朝上**」，即 `M·(0,0,−1) = (0,1,0)`；
 * `length: '-x'` 读作「源模型的 −x 方向指向 +x」，即 `M·(−1,0,0) = (+1,0,0)`。
 *
 * ⇒ **符号属于"源模型的哪一端"，不属于别的任何东西。**
 *   若实现成"取绝对值再另作处理"，就会差一个翻转 —— 而**镜像的包围盒与原模型完全相同**。
 *
 * ══════════════════════════════════════════════════════════════════════════
 * ⚠️⚠️ `up` 与 `length` **必须落在不同的轴上** —— 否则 det = 0，模型被压平
 * ══════════════════════════════════════════════════════════════════════════
 *
 * 一条轴**不可能同时**映到 `+y` 和 `+x`。若 `up` 与 `length` 指向同一条轴
 * （如 `up: '+z', length: '+z'`，或 `'+z'` / `'-z'` 这种同轴异号）：
 *
 * ```text
 * ⇒ 变换矩阵某一行全零 ⇒ det = 0
 * ⇒ 结果不是"转错"，而是**几何被压平成一张纸**，而且**不会有任何报错**
 * ```
 *
 * **消费方应当**：检测到同轴就**退回自动规则**并上报（UI 出 **error**），
 * **不要抛异常**（不能让一个数据错误把整个模型变成空白），**也不要渲染压平的垃圾**。
 *
 * ★ 这与上面那条"det 必须为 +1"是**两个不同的约束**，都要查：
 *   · `det = −1` ⇒ **镜像**（模型翻转，端口落到错误一侧，包围盒不变）
 *   · `det = 0`  ⇒ **压平**（退化，模型塌成一张纸）
 */
export interface ModelOrientation {
    /** 源模型里哪条轴是**厚度/上**（会被映到 **+y**）。 */
    readonly up: SourceAxis;
    /** 源模型里哪条轴是**长度**（会被映到 **+x**）。**必须与 `up` 不同轴。** */
    readonly length: SourceAxis;
}
/** 一个预置硬件型号的接口语义 + 几何尺寸。 */
export interface HardwareModel {
    /** 模型库键。前端按它加载几何；`ComponentSpec.hardwareModel` 存的就是它。 */
    readonly key: string;
    readonly label: string;
    /**
     * **朝向覆盖** —— 人工指定"源模型里哪条轴是厚度、哪条是长度"。
     *
     * ★ 触发条件已经响了（公约原文「per-model override 字段**等首个真实模型落地时再加**」）：
     *   实测 `mpl3115a2` 的长/宽是 **19.05 vs 17.78，只差 7%**，而两条都是**水平轴**
     *   ⇒ "哪条是长"**不是测量结果，而是约定**。判错了模型会在平面内转 90°，
     *     而**包围盒完全看不出来**。这种情况必须由人指定，不能靠阈值硬猜。
     *
     * ⚠️⚠️ **实现者注意：只能产出旋转（det = +1），绝不能产出反射（det = −1）。**
     *   6 种尺寸序里**有 3 种是反射**（`x>y>z` / `y>z>x` / `z>x>y`），
     *   而 `x>y>z` **恰好就是两个 Adafruit 传感器模型的尺寸序**。
     *
     *   反射会把模型**镜像**，而 `Port.position` 是**手写在归一化坐标系里、不会被一起镜像**的
     *   ⇒ 板子左右翻转、**端口落到错误的一侧**，而**包围盒一模一样** ⇒
     *   **长宽比告警不会触发，一切看起来都对**。
     *
     *   ⇒ **镜像比"转错 90°"更隐蔽，因为它连尺寸都对。**
     *     务必按「定 up → 定 length → 第三轴由 det=+1 反解」实现，**不要做轴置换**。
     *
     * ★ 同一个包围盒对应 **4 个真旋转**（上下翻转 × 长度方向翻转）——
     *   包围盒**量不出**这两个自由度，所以它们是**约定**，实现里应明写而不是藏起来。
     *
     * 省略 = 走自动规则（最薄→+y、其余较长的→+x）。
     */
    readonly orientation?: ModelOrientation;
    /**
     * **3D 包围盒**尺寸（米）：x = 长，y = 厚/高，z = 宽。
     * ★ 这是几何尺寸的**唯一出处** —— 前端只保留颜色/材质，尺寸从这里取。
     *
     * ⚠️⚠️ **它不是 PCB 封装（land pattern）尺寸，二者不可互换。**
     *   厂商的结构化元数据（引脚/焊盘）给的是**二维封装范围**，而这里是**三维包络**：
     *
     *   | 型号类型 | 封装尺寸 ≈ 3D 尺寸？ | 例子 |
     *   |---|---|---|
     *   | 裸 IC | ✅ 基本等价 | BME280 芯片：2.5×2.5mm |
     *   | **模块 / 板卡** | ❌ **差一个数量级** | BME280 **模块** 20×18mm；树莓派 PCB 1.6mm vs 含接口 17mm |
     *
     *   拿封装尺寸当 `size` 的后果是**具体的**：`restingY()` 返回 `size.y/2`，
     *   树莓派会得到 0.0008 而不是 0.0085 —— **板子直接陷进地面**，端口锚点全部错位。
     *
     *   ⇒ 从厂商元数据导入型号时，**`size` 必须另有来源**（厂商另给的 3D 包络、
     *     或人工量取）。凡是从封装尺寸推出来的，都是半自动流程，成本要如实计入。
     */
    readonly size: Vec3;
    /**
     * 端口定义（组件局部坐标，原点 = 包围盒中心）。
     * `occupiedBy` 由 AssemblyState 在生成快照时填，这里只给静态语义。
     */
    readonly ports: readonly Port[];
    /** I2C 从机地址（若该型号是 I2C 设备）。用于地址冲突检测。 */
    readonly i2cAddress?: number;
    /** 自身功耗（瓦）。用于供电预算。 */
    readonly powerDrawW: number;
    /** 可作为电源，提供多少瓦预算。非电源为 0。 */
    readonly powerSupplyW: number;
}
/** 作者时端口声明：**语义**（位置可由 `portLayout` 派生）。 */
export type PortSpec = Omit<Port, 'position' | 'occupiedBy'> & {
    /** 显式位置。省略时由 `portLayout` 派生；两者都缺则解析时报错。 */
    readonly position?: Vec3;
};
/** 作者时型号声明（`ports` 允许省略位置）。 */
export interface HardwareModelSource extends Omit<HardwareModel, 'ports'> {
    readonly ports: readonly PortSpec[];
    readonly portLayout?: PortLayoutRule;
}
/** 布局规则不合法时抛出。**在模型表构造时**就抛，不等到运行时。 */
export declare class PortLayoutError extends Error {
    constructor(message: string);
}
/**
 * 结构性校验 —— 这是声明式布局相对手打坐标的**主要收益**。
 *
 * 逐点校验只能告诉你「某个点越界了」；这里能拦住**规则本身就不合理**的情况，
 * 最典型的是 `pitch×(count−1) + 2×inset > 沿边轴长度` ——
 * **一行端口比板子还长**，在"写规则"那一刻就被拦下，而不是跑完才发现。
 */
export declare function validateLayout(model: HardwareModelSource, rule: PortLayoutRule): void;
/** 把作者时声明解析成运行时模型（端口位置全部落实）。 */
export declare function resolveModel(source: HardwareModelSource): HardwareModel;
/**
 * 预置型号表（**已解析**，端口位置全部落实）。
 *
 * ★ 解析在模块加载时**一次完成** ⇒ 运行时零开销，且规则错误会在加载时立刻暴露。
 */
export declare const HARDWARE_MODELS: Readonly<Record<string, HardwareModel>>;
/** 查型号。未知型号返回 undefined（调用方据此发 `unknown_hardware_model` 警告）。 */
export declare function findModel(key: string): HardwareModel | undefined;
/** 全部预置型号键。 */
export declare function modelKeys(): string[];
/** 让组件「平放在地面」时应当使用的高度（y = 半厚）。见文件头的原点约定。 */
export declare function restingY(modelKey: string): number;
/**
 * 由型号实例化出一个组件。
 *
 * @param id - 组件唯一 id（调用方提供，保证可复现）
 * @param modelKey - 型号键
 * @param position - **包围盒中心**的世界坐标（米）
 */
export declare function instantiate(id: string, modelKey: string, position: Vec3, rotation?: Vec3): import('./assembly.ts').ComponentSpec | undefined;
/** 判断某型号是否提供该协议端口。 */
export declare function modelSupportsProtocol(model: HardwareModel, protocol: Protocol): boolean;
