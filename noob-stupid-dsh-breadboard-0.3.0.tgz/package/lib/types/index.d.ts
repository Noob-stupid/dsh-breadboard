/**
 * @noob-stupid/dsh-breadboard —— 插件宿主半入口
 *
 * 本文件是**宿主半（Node）**的组装点。它刻意保持单薄：
 * 内核逻辑全部在 src/core/**，且**零依赖 DSH 宿主 API**（§10.3 硬要求），
 * 因此内核可脱离宿主单测（`npm test`，67 项全绿）。
 * 与宿主打交道的一切都收在 src/host/**（薄适配层，§10）。
 *
 * ── 施工进度（顺序见 docs/01-项目定位.md §7） ──
 *   ① 虚拟时钟 + 确定性设备              ✅ T1/T2/T3/T5/T6 全绿
 *   ② BridgeServer(TCP) + bridge_client  ✅ 真 Python 走 shim 跑通（tests/python-shim.test.ts）
 *   ③ BME280 寄存器级行为模型            ✅ 含 BigInt 补偿与二分反解（tests/bme280.test.ts）
 *   ④ test-project 适配                  ⬜ 未开始（见 docs/06 §5：真实项目形态与 I2C 沙盒不同）
 *   ⑤ SimEngine + 工具注册               ✅ 引擎 + 4 个工具已接（本文件「仿真引擎与工具」段）
 *   ⑥ HostAdapter 接真实 DSH             ✅ AssemblyState(SSOT) + 路由 + 工具 + 模型库
 *   ⑦ 前端 Three.js 场景                 🔄 由 session-40f8f716 并行推进
 */
import z from '@deepseek-ai/schemastery';
import { type HttpRoute, type UpgradeRoute } from './host/routes.ts';
/**
 * 宿主能力面。
 *
 * ★ 刻意用**结构化类型**而不是 import 宿主类型：
 *   §10.3 要求内核零依赖宿主 API；本文件就是那条边界。
 *   宿主接口若改名或迁移，改动收敛在此处，src/core/** 不受影响。
 */
interface WebServerLike {
    register(route: HttpRoute): () => void;
    registerUpgrade(route: UpgradeRoute): () => void;
}
interface AppContext {
    readonly webServer?: WebServerLike;
    readonly subprocess?: unknown;
    /** Cordis 的可选服务访问。**用它而不是硬 inject** —— 见下方搜索能力的降级说明。 */
    get?(name: string): unknown;
    logger?: {
        info?(message: string): void;
        warn?(message: string): void;
    };
    effect?(callback: () => (() => void) | void, label?: string): () => void;
}
/**
 * 插件名 = **npm 包名**，唯一出处是 `contracts/protocol.ts` 的 `PLUGIN_PACKAGE_NAME`
 * （前端半的 Star 钩子用它判断"这一页是不是本插件"，两边必须是同一个字面量）。
 */
export declare const name: "@noob-stupid/dsh-breadboard";
/**
 * 需要宿主提供的服务。
 *
 * ★ `webServer` / `subprocess` / `tools` 都放在**硬依赖**里，而不是用 `ctx.get()` 探测。
 *   理由是这三者的缺失都属于**静默归零**：
 *   · 没有 `webServer` ⇒ 前端连不上，界面看着"加载了"却永远空白
 *   · 没有 `tools`     ⇒ 工具根本没注册，模型只会说"我没有这个能力"，没人知道为什么
 *   · 没有 `subprocess` ⇒ 仿真永远起不来
 *   硬依赖的语义是"**等到就绪再激活**"，于是这些能力要么可用、要么插件压根不激活，
 *   **不存在"激活了但功能悄悄没了"这一档**。宁可晚激活，不要假激活。
 *
 *   （对照：`web` 搜索服务走 `ctx.get()` 可选获取 —— 它缺失时面板会明确显示
 *     "搜索不可用"，是**可见的**降级，与上面三种静默归零性质不同。）
 */
export declare const inject: string[];
export interface Config {
    /** 虚拟时钟最小时间片（秒）。默认 1ms。 */
    step: number;
    /** 宿主事件循环让出预算（毫秒）。默认 1（实测最优，见 virtual-clock.ts）。 */
    yieldBudgetMs: number;
    /** 单次 advance 的虚拟时长上限（秒）。 */
    maxAdvanceSeconds: number;
    /** 启动时跑一次内核自检并打印结果。 */
    selfCheck: boolean;
    /**
     * 启动时铺一套演示装配（树莓派 + BME280 + I2C 连线）。
     *
     * ⚠️ 这是**联调辅助**：让前端一连上就有内容可渲染，便于端到端验证。
     *    正式形态应由「新建项目」流程驱动，届时置 false。
     */
    seedDemo: boolean;
    /** 本机 Python 解释器路径（主线 B 用）。留空表示未探测。 */
    pythonPath: string;
    /**
     * 用户导入模型的存储目录。留空则用 `$DSH_HOME/dsh-hardware-sandbox/models`。
     *
     * ★ 落在**用户数据目录**，不是插件包内 —— 插件**不分发**任何第三方模型。
     */
    modelsDir: string;
}
export declare const Config: z<Schemastery.ObjectS<NoInfer<{
    step: z<number, number, "defined">;
    yieldBudgetMs: z<number, number, "defined">;
    maxAdvanceSeconds: z<number, number, "defined">;
    selfCheck: z<boolean, boolean, "defined">;
    seedDemo: z<boolean, boolean, "defined">;
    pythonPath: z<string, string, "defined">;
    modelsDir: z<string, string, "defined">;
}>>, Schemastery.ObjectT<NoInfer<{
    step: z<number, number, "defined">;
    yieldBudgetMs: z<number, number, "defined">;
    maxAdvanceSeconds: z<number, number, "defined">;
    selfCheck: z<boolean, boolean, "defined">;
    seedDemo: z<boolean, boolean, "defined">;
    pythonPath: z<string, string, "defined">;
    modelsDir: z<string, string, "defined">;
}>>, "plain">;
export declare function apply(ctx: AppContext, config: Config): void;
export {};
